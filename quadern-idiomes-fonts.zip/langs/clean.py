import sys,glob
for f in glob.glob(f'{sys.argv[1]}/[a-z][0-9]*.txt'):
    L=open(f).read().split('\n'); out=[]
    for l in L:
        p=[x.strip() for x in l.split('|')]
        if len(p)>1 and all(x in ('—','') for x in p[1:]): continue
        out.append(l)
    open(f,'w').write('\n'.join(out))
