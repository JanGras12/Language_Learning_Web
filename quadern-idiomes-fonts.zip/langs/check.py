import sys,glob,collections
lang=sys.argv[1]; NF=dict(x.split(':') for x in sys.argv[2].split(','))
seen={}; tot=collections.Counter()
for f in sorted(glob.glob(f'{lang}/[a-z][0-9]*.txt')):
    k=f.split('/')[-1][0]
    if k not in NF: continue
    for i,l in enumerate(open(f),1):
        l=l.rstrip('\n')
        if not l.strip() or l.startswith('#'): continue
        p=[x.strip() for x in l.split('|')]
        if len(p)!=int(NF[k]): print('FIELDS',f,i,l); continue
        key=p[0]
        if key in seen: print('DUP',f,i,key,'<->',seen[key])
        else: seen[key]=f'{f}:{i}'
        tot[k]+=1
print(dict(tot))
