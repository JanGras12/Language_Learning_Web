# -*- coding: utf-8 -*-
"""Motor comú per als quaderns d'idiomes (format del model rus / japonès)."""
import glob, math, collections
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.worksheet.datavalidation import DataValidation
from openpyxl.utils import get_column_letter

DARK = '1F3864'; BLUE = '2E75B6'
thin = Side(style='thin', color='BFBFBF'); BOX = Border(left=thin, right=thin, top=thin, bottom=thin)
F_HEAD = Font(name='Calibri', bold=True, size=10, color='FFFFFF')
F_SEC = Font(name='Calibri', bold=True, size=11, color='FFFFFF')
F_BODY = Font(name='Calibri', size=10)
FILL_H = PatternFill('solid', fgColor=DARK); FILL_S = PatternFill('solid', fgColor=BLUE)
WRAP = Alignment(wrap_text=True, vertical='center'); WRAPC = Alignment(wrap_text=True, vertical='center', horizontal='center')

def vis_len(s):
    return sum(2 if ord(ch) > 0x2E80 else 1 for ch in str(s))

def set_height(ws, r, values, widths, base=15):
    lines = 1
    for v, w in zip(values, widths):
        if v is None: continue
        lines = max(lines, math.ceil(vis_len(v) / max(w * 1.05, 1)))
    ws.row_dimensions[r].height = max(base, 14 * lines + 4)

def read(folder, prefix, nf):
    """Llegeix fitxers data/<prefix>NN.txt; seccions '# Nom'; camps separats per '|'. Fusiona seccions amb el mateix nom."""
    secs = collections.OrderedDict(); cur = None; bad = []
    for f in sorted(glob.glob(f'{folder}/{prefix}[0-9]*.txt')):
        for i, l in enumerate(open(f, encoding='utf-8'), 1):
            l = l.rstrip('\n')
            if not l.strip(): continue
            if l.startswith('#'):
                cur = l[1:].strip(); secs.setdefault(cur, []); continue
            p = [x.strip() for x in l.split('|')]
            if len(p) != nf: bad.append((f, i, l)); continue
            if p[1] == '—' and nf > 3 and all(x in ('—', '') for x in p[1:]): continue
            secs[cur].append(p)
    return secs, bad

def dedupe(secs_list, keyfn):
    """Elimina repeticions (mateixa clau) a tots els fulls, en ordre."""
    seen = {}; dups = []
    for name, secs in secs_list:
        for sec in secs:
            keep = []
            for p in secs[sec]:
                k = keyfn(name, p)
                if k in seen: dups.append((name, sec, p[0], seen[k])); continue
                seen[k] = name; keep.append(p)
            secs[sec] = keep
    return dups

def count(secs): return sum(len(v) for v in secs.values())

class Book:
    def __init__(self, font_tl='Calibri', tl_size=12):
        self.wb = Workbook(); self.wb.remove(self.wb.active)
        self.F_TL = Font(name=font_tl, size=tl_size, bold=True, color=DARK)
        self.font_tl = font_tl

    def vocab(self, name, headers, widths, secs, rowfn, tlcols, tab=BLUE, center=(), rtl_cols=()):
        ws = self.wb.create_sheet(name); ws.sheet_properties.tabColor = tab
        for i, w in enumerate(widths, 1): ws.column_dimensions[get_column_letter(i)].width = w
        for i, h in enumerate(headers, 1):
            c = ws.cell(1, i, h); c.font = F_HEAD; c.fill = FILL_H; c.alignment = WRAPC; c.border = BOX
        ws.row_dimensions[1].height = 32
        r = 2
        for sec, rows in secs.items():
            if not rows: continue
            for i in range(1, len(headers) + 1): ws.cell(r, i).fill = FILL_S
            c = ws.cell(r, 1, sec); c.font = F_SEC; c.alignment = Alignment(vertical='center')
            ws.row_dimensions[r].height = 20; r += 1
            for p in rows:
                vals = rowfn(p)
                for i, v in enumerate(vals, 1):
                    c = ws.cell(r, i, v); c.border = BOX
                    if i in rtl_cols: c.alignment = Alignment(wrap_text=True, vertical='center', horizontal='right', readingOrder=2)
                    else: c.alignment = WRAPC if i in center else WRAP
                    c.font = self.F_TL if i in tlcols else F_BODY
                set_height(ws, r, vals, widths); r += 1
        last = r - 1
        col = get_column_letter(len(headers))
        dv = DataValidation(type='list', formula1='"✓"', allow_blank=True)
        ws.add_data_validation(dv); dv.add(f'{col}2:{col}{last}')
        ws.freeze_panes = 'C2'
        ws.auto_filter.ref = f'A1:{col}{last}'
        return ws

    def gram(self, name, blocks, widths, tab='548235', rtl=False):
        ws = self.wb.create_sheet(name); ws.sheet_properties.tabColor = tab; ws.sheet_view.showGridLines = False
        ncol = len(widths)
        for i, w in enumerate(widths, 1): ws.column_dimensions[get_column_letter(i)].width = w
        total = sum(widths); r = 1
        for b in blocks:
            kind = b[0]
            if kind == 'T':
                ws.merge_cells(start_row=r, start_column=1, end_row=r, end_column=ncol)
                c = ws.cell(r, 1, b[1]); c.font = Font(bold=True, size=12, color='FFFFFF'); c.fill = FILL_S; c.alignment = WRAP
                ws.row_dimensions[r].height = 24
            elif kind == 'P':
                ws.merge_cells(start_row=r, start_column=1, end_row=r, end_column=ncol)
                c = ws.cell(r, 1, b[1]); c.font = F_BODY; c.alignment = Alignment(wrap_text=True, vertical='top')
                ws.row_dimensions[r].height = max(18, 14 * math.ceil(vis_len(b[1]) / (total * 1.1)) + 6)
            elif kind == 'H':
                for i, v in enumerate(b[1], 1):
                    c = ws.cell(r, i, v); c.font = F_HEAD; c.fill = FILL_H; c.alignment = WRAPC; c.border = BOX
                set_height(ws, r, b[1], widths, base=22)
            elif kind == 'R':
                for i, v in enumerate(b[1], 1):
                    c = ws.cell(r, i, v); c.border = BOX; c.alignment = WRAP
                    tl = any(ord(ch) > 0x0590 for ch in str(v))
                    c.font = Font(name=self.font_tl if tl else 'Calibri', bold=(i == 1), size=11 if tl else 10)
                set_height(ws, r, b[1], widths, base=18)
            r += 1
        return ws

    def guia(self, rows):
        g = self.wb.create_sheet('Guia', 0); g.sheet_properties.tabColor = 'C00000'
        for col, w in zip('ABC', (32, 74, 50)): g.column_dimensions[col].width = w
        g.sheet_view.showGridLines = False
        r = 1
        for row in rows:
            if row[0] == 'title':
                c = g.cell(r, 1, row[1]); c.font = Font(bold=True, size=16, color=DARK); g.row_dimensions[r].height = 26
            elif row[0] == 'head':
                for col in range(1, 4): g.cell(r, col).fill = FILL_S
                c = g.cell(r, 1, row[1]); c.font = Font(bold=True, size=12, color='FFFFFF'); g.row_dimensions[r].height = 20
            elif row[0] == 'kv':
                a = g.cell(r, 1, row[1]); a.font = Font(bold=True, size=10); a.alignment = Alignment(wrap_text=True, vertical='top')
                b = g.cell(r, 2, row[2]); b.font = Font(size=10); b.alignment = Alignment(wrap_text=True, vertical='top')
                if len(row) > 3 and row[3]:
                    c = g.cell(r, 3, row[3]); c.font = Font(size=10, italic=True); c.alignment = Alignment(wrap_text=True, vertical='top')
                set_height(g, r, [row[1], row[2], row[3] if len(row) > 3 else None], [32, 74, 50], base=16)
            r += 1
        self.wb.active = 0

    def save(self, path): self.wb.save(path)

class Blocks:
    def __init__(self): self.B = []
    def T(self, s): self.B.append(('T', s))
    def P(self, s): self.B.append(('P', s))
    def H(self, *c): self.B.append(('H', list(c)))
    def R(self, *c): self.B.append(('R', list(c)))
    def E(self): self.B.append(('B',))
