"""Fusiona homògrafs repetits: afegeix el significat del duplicat a la primera aparició i elimina el duplicat.
Ús: python3 merge.py <lang> <prefix>:<camp_traducció>,...   (camp 0-indexat)"""
import sys,glob
lang=sys.argv[1]; spec=dict(x.split(':') for x in sys.argv[2].split(','))
files=sorted(glob.glob(f'{lang}/[a-z][0-9]*.txt'))
data={f:[l.rstrip('\n') for l in open(f)] for f in files}
first={}
for f in files:
    k=f.split('/')[-1][0]
    if k not in spec: continue
    ci=int(spec[k])
    for i,l in enumerate(data[f]):
        if not l.strip() or l.startswith('#'): continue
        p=l.split('|')
        if p[0] in first:
            ff,ii=first[p[0]]; q=data[ff][ii].split('|')
            add=[m.strip() for m in p[ci].split(';') if m.strip() and m.strip() not in q[ci]]
            if add: q[ci]=q[ci]+'; '+'; '.join(add); data[ff][ii]='|'.join(q)
            data[f][i]=None; print('merged',p[0],'->',q[ci])
        else: first[p[0]]=(f,i)
for f in files:
    open(f,'w').write('\n'.join(l for l in data[f] if l is not None)+'\n')
