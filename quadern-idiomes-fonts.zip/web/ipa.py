"""IPA aproximada: japonès (des del kana) i rus (des de la paraula amb accent marcat).
També genera la pronunciació «a la catalana» per a paraules russes noves."""
import re, unicodedata

# ------------------------------------------------------------------ JAPONÈS
_H = {}
def _add(kana, onset, vowel):
    _H[kana] = (onset, vowel)
for row in [
    ('あいうえお', ''), ('かきくけこ', 'k'), ('がぎぐげご', 'ɡ'), ('さしすせそ', 's'), ('ざじずぜぞ', 'z'),
    ('たちつてと', 't'), ('だぢづでど', 'd'), ('なにぬねの', 'n'), ('はひふへほ', 'h'), ('ばびぶべぼ', 'b'),
    ('ぱぴぷぺぽ', 'p'), ('まみむめも', 'm'), ('らりるれろ', 'ɾ')]:
    for k, v in zip(row[0], 'aiɯeo'):
        _add(k, row[1], v)
for k, v in zip('やゆよ', 'aɯo'): _add(k, 'j', v)
_add('わ', 'w', 'a'); _add('を', '', 'o'); _add('ゔ', 'b', 'ɯ')
_SPECIAL = {'し': 'ɕ', 'じ': 'dʑ', 'ぢ': 'dʑ', 'ち': 'tɕ', 'つ': 'ts', 'づ': 'dz', 'ず': 'dz', 'に': 'ɲ', 'ひ': 'ç', 'ふ': 'ɸ'}
for k, o in _SPECIAL.items(): _H[k] = (o, _H[k][1])
_SMALLY = {'ゃ': 'a', 'ゅ': 'ɯ', 'ょ': 'o'}
_SMALLV = {'ぁ': 'a', 'ぃ': 'i', 'ぅ': 'ɯ', 'ぇ': 'e', 'ぉ': 'o'}

def _kata2hira(s):
    return ''.join(chr(ord(c) - 0x60) if 'ァ' <= c <= 'ヶ' else c for c in s)

def ja_ipa(kana, verb=False):
    s = _kata2hira(kana.replace('〜', '').replace('～', '').strip())
    s = re.split(r'[（(/／・,、]', s)[0].strip()
    if not s:
        return ''
    morae = []  # (onset, vowel) | ('Q',) | ('N',) | ('L',)
    i = 0
    while i < len(s):
        c = s[i]; nx = s[i + 1] if i + 1 < len(s) else ''
        if c in 'っ':
            morae.append(('Q',)); i += 1; continue
        if c == 'ん':
            morae.append(('N',)); i += 1; continue
        if c == 'ー':
            morae.append(('L',)); i += 1; continue
        if c in _H:
            on, v = _H[c]
            if nx in _SMALLY:
                y = _SMALLY[nx]
                if on in ('ɕ', 'dʑ', 'tɕ', 'ç', 'ɲ'):
                    morae.append((on, y))
                else:
                    pal = {'k': 'kʲ', 'ɡ': 'ɡʲ', 'b': 'bʲ', 'p': 'pʲ', 'm': 'mʲ', 'ɾ': 'ɾʲ', 'h': 'ç', 'n': 'ɲ'}.get(on, on + 'ʲ')
                    morae.append((pal, y))
                i += 2; continue
            if nx in _SMALLV:  # ファ, ティ, ウィ...
                v2 = _SMALLV[nx]
                on2 = {'ɸ': 'ɸ', 'ts': 'ts', 'te': 't', '': 'w'}.get(on, on)
                if c in 'てで' and v2 == 'i': on2 = 't' if c == 'て' else 'd'
                if c == 'う': on2 = 'w'
                morae.append((on2, v2)); i += 2; continue
            morae.append((on, v)); i += 1; continue
        if c in ' 　':
            morae.append(('SP',)); i += 1; continue
        i += 1  # caràcter desconegut: s'ignora
    out = []
    for j, m in enumerate(morae):
        nxt = morae[j + 1] if j + 1 < len(morae) else None
        if m[0] == 'SP':
            out.append(' '); continue
        if m[0] == 'Q':
            if nxt and len(nxt) == 2 and nxt[0]:
                o = nxt[0]
                out.append(o[0] + 'ː' if len(o) == 1 else o[0] + 'ː')
                morae[j + 1] = (o[1:] if len(o) > 1 else '', nxt[1]) if len(o) > 1 else ('', nxt[1])
                if len(o) == 1:
                    pass
            else:
                out.append('ʔ')
            continue
        if m[0] == 'N':
            o = nxt[0] if nxt and len(nxt) == 2 else ''
            if o[:1] in ('p', 'b', 'm'): out.append('m')
            elif o[:1] in ('t', 'd', 'n', 'ɾ') or o in ('ts', 'dz'): out.append('n')
            elif o[:2] in ('tɕ', 'dʑ') or o[:1] == 'ɲ': out.append('ɲ')
            elif o[:1] in ('k', 'ɡ'): out.append('ŋ')
            else: out.append('ɴ')
            continue
        if m[0] == 'L':
            out.append('ː'); continue
        on, v = m
        prev = morae[j - 1] if j > 0 else None
        last = (j == len(morae) - 1)
        # vocal llarga: mateixa vocal, おう, えい (no a final de verb)
        if on == '' and prev and len(prev) == 2 and prev[0] != 'SP':
            pv = prev[1]
            if (pv == v and v != 'ɯ' or pv == v == 'ɯ') or (pv == 'o' and v == 'ɯ') or (pv == 'e' and v == 'i'):
                if not (verb and last and v == 'ɯ'):
                    out.append('ː'); continue
        if on == 'z' and (j == 0 or (prev and prev[0] == 'N')): on = 'dz'
        out.append(on + v)
    r = ''.join(out)
    return '[' + r.replace('ːː', 'ː') + ']'

# ------------------------------------------------------------------ RUS
ACC = '́'
VOW = 'аеёиоуыэюя'
SOFTV = {'е': 'e', 'ё': 'o', 'ю': 'u', 'я': 'a', 'и': 'i'}
HARDV = {'а': 'a', 'о': 'o', 'у': 'u', 'ы': 'y', 'э': 'e'}
CONS = 'бвгджзйклмнпрстфхцчшщ'
ALWAYS_HARD = set('жшц')
ALWAYS_SOFT = set('чщй')
UNSTRESSED_WORDS = set('в во на с со к ко у о об обо и а но не ни бы же ли за по из от до без для под над про при то ль б ж'.split())
GEN_V = set('его кого чего ничего того всего этого своего моего твоего нашего вашего одного сегодня сегодняшний'.split())

def _norm(w):
    return unicodedata.normalize('NFC', w.lower())

def _prep(word):
    """Simplificacions ortogràfiques de pronunciació (consonants mudes, grups)."""
    w = word
    plain = w.replace(ACC, '')
    reps = [('вств', 'ств'), ('лнц', 'нц'), ('рдц', 'рц'), ('стн', 'сн'), ('здн', 'зн'), ('стл', 'сл'),
            ('сч', 'щ'), ('зч', 'щ'), ('жч', 'щ'), ('ться', 'ца'), ('тся', 'ца'), ('гк', 'хк'), ('гч', 'хч')]
    for a, b in reps:
        # aplica només si la seqüència no porta accent enmig
        w = w.replace(a, b)
    if plain.startswith('что') or plain.startswith('чтоб'):
        w = 'ш' + w[1:]
    for pre in ('конечн', 'скучн', 'нарочн', 'яичниц'):
        if plain.startswith(pre):
            w = w.replace('чн', 'шн', 1)
    if plain in GEN_V or plain.startswith('сегодн'):
        w = re.sub('г(?=' + ACC + '?[оo])', 'в', w, count=1) if plain.startswith('сегодн') else w[::-1].replace('ог', 'ов', 1)[::-1]
    return w

def _units(word):
    """Llista d'unitats: ('C', lletra, tova) / ('J',) / ('V', vocal_base, accent, despres_de_tova, hard_after)"""
    w = _norm(word)
    w = _prep(w)
    u = []
    sep = True  # inici de paraula
    for i, ch in enumerate(w):
        if ch == ACC:
            for k in range(len(u) - 1, -1, -1):
                if u[k][0] == 'V':
                    u[k] = ('V', u[k][1], True, u[k][3], u[k][4]); break
            continue
        if ch in CONS:
            u.append(['C', ch, ch in ALWAYS_SOFT]); sep = False; continue
        if ch == 'ь':
            if u and u[-1][0] == 'C' and u[-1][1] not in ALWAYS_HARD: u[-1][2] = True
            sep = True; continue
        if ch == 'ъ':
            sep = True; continue
        if ch in VOW:
            prevC = u[-1] if (u and u[-1][0] == 'C' and sep is False) else None
            stressed = (ch == 'ё')
            if ch in SOFTV:
                base = SOFTV[ch]
                if prevC:
                    if prevC[1] in ALWAYS_HARD:
                        if base == 'i': base = 'y'
                        u.append(('V', base, stressed, False, True))
                    else:
                        prevC[2] = True
                        u.append(('V', base, stressed, True, False))
                else:
                    if not (ch == 'и' and sep is not True) and not (ch == 'и' and not u):
                        u.append(('J',))
                    u.append(('V', base, stressed, True, False))
            else:
                base = HARDV[ch]
                hard_after = bool(prevC and prevC[1] in ALWAYS_HARD)
                u.append(('V', base, stressed, bool(prevC and prevC[2]), hard_after))
            sep = 'V'
            continue
        # altres caràcters (guió) s'ignoren
    # 'sep' = 'V' significa que la unitat anterior és vocal: tractat a dalt via `sep` truthy
    return [tuple(x) if isinstance(x, list) else x for x in u]

VOICED = {'b': 'p', 'v': 'f', 'ɡ': 'k', 'd': 't', 'z': 's', 'ʐ': 'ʂ', 'ʑ': 'ɕ'}
VOICELESS = {v: k for k, v in VOICED.items()}
VOICELESS.update({'x': 'ɣ', 'ts': 'dz', 'tɕ': 'dʑ'})
CIPA = {'б': 'b', 'в': 'v', 'г': 'ɡ', 'д': 'd', 'ж': 'ʐ', 'з': 'z', 'к': 'k', 'л': 'l', 'м': 'm', 'н': 'n', 'п': 'p',
        'р': 'r', 'с': 's', 'т': 't', 'ф': 'f', 'х': 'x', 'ц': 'ts', 'ч': 'tɕ', 'ш': 'ʂ', 'щ': 'ɕː', 'й': 'j'}
OBSTR = set('bvɡdzʐpfkstʂxɕ') | {'ts', 'tɕ', 'ɕː'}

def _stress_index(units):
    vs = [i for i, x in enumerate(units) if x[0] == 'V']
    for i in vs:
        if units[i][2]:
            return i
    return None

def ru_word_ipa(word):
    plain = _norm(word).replace(ACC, '')
    units = _units(word)
    vs = [i for i, x in enumerate(units) if x[0] == 'V']
    s = _stress_index(units)
    if s is None and len(vs) == 1 and plain not in UNSTRESSED_WORDS:
        s = vs[0]
    out = []  # list of [symbol, kind]
    for k, x in enumerate(units):
        if x[0] == 'J':
            out.append(['j', 'J']); continue
        if x[0] == 'C':
            sym = CIPA[x[1]]
            soft = x[2] and x[1] not in ALWAYS_SOFT
            if x[1] == 'л' and not x[2]: sym = 'ɫ'
            out.append([sym + ('ʲ' if soft else ''), 'C']); continue
        _, b, st, after_soft, after_hard = x
        prevsoft = (k > 0 and (units[k - 1][0] == 'J' or (units[k - 1][0] == 'C' and units[k - 1][2])))
        is_final = (k == len(units) - 1)
        if s is not None and k == s:
            v = {'a': 'a', 'o': 'o', 'u': 'u', 'y': 'ɨ', 'i': 'i', 'e': 'e' if prevsoft else 'ɛ'}[b]
            if b == 'e' and after_hard: v = 'ɛ'
        else:
            pret = s is not None and k < s and (vs.index(k) == vs.index(s) - 1)
            initial = (k == 0)
            if b in 'ao':
                if prevsoft: v = 'ə' if is_final else 'ɪ'
                elif after_hard: v = 'ɐ' if (pret or initial) else 'ə'
                else: v = 'ɐ' if (pret or initial) else 'ə'
            elif b == 'e':
                if after_hard: v = 'ɨ'
                elif prevsoft: v = 'ɪ'
                else: v = 'ɪ'
            elif b == 'u': v = 'ʊ'
            elif b == 'i': v = 'ɪ'
            elif b == 'y': v = 'ɨ'
            if s is None and len(vs) == 1: v = {'ɐ': 'a', 'ə': 'a', 'ʊ': 'u', 'ɪ': 'i'}.get(v, v)
            if b == 'a' and prevsoft and is_final: v = 'ə'
        out.append([('ˈ' if (s is not None and k == s and len(vs) > 1) else '') + v, 'V'])
    # assimilació de sonoritat (de dreta a esquerra)
    def base(sym):
        return sym.replace('ʲ', '').replace('ː', '')
    nextv = None  # 'voiced' / 'voiceless' / None
    for k in range(len(out) - 1, -1, -1):
        sym, kind = out[k]
        if kind != 'C':
            nextv = None; continue
        b = base(sym)
        soft = 'ʲ' in sym
        if b in VOICED or b in VOICELESS or b in OBSTR:
            if k == len(out) - 1 or nextv == 'voiceless':
                if b in VOICED: out[k][0] = VOICED[b] + ('ʲ' if soft else '')
            elif nextv == 'voiced' and b in VOICELESS and b not in ('x',):
                out[k][0] = VOICELESS[b] + ('ʲ' if soft else '')
            nb = base(out[k][0])
            if nb == 'v' or nb == 'f' and b == 'v':
                pass
            nextv = 'voiced' if nb in VOICED and nb != 'v' else ('voiceless' if nb in OBSTR else None)
            if b == 'v' and nb == 'v': nextv = None
        else:
            nextv = None
    # posa l'accent al començament de síl·laba (abans de l'atac)
    syms = [o[0] for o in out]
    res = ''.join(syms)
    if 'ˈ' in res:
        idx = next(i for i, o in enumerate(out) if o[0].startswith('ˈ'))
        out[idx][0] = out[idx][0][1:]
        j = idx
        cons = []
        while j - 1 >= 0 and out[j - 1][1] in ('C', 'J'):
            j -= 1
        nC = idx - j
        # atac: una consonant (o grup inicial de paraula / obstruent+líquida)
        if j == 0:
            start = 0
        elif nC <= 1:
            start = idx - nC
        else:
            last2 = [base(out[idx - 2][0]), base(out[idx - 1][0])]
            start = idx - 2 if (last2[1] in ('r', 'l', 'ɫ', 'j') and last2[0] in OBSTR) else idx - 1
        syms = [o[0] for o in out]
        syms.insert(start, 'ˈ')
        res = ''.join(syms)
    return res

def ru_ipa(text):
    words = re.findall(r"[а-яёА-ЯЁ́\-]+", text)
    return '[' + ' '.join(ru_word_ipa(w.replace('-', '')) for w in words if w.strip('-')) + ']' if words else ''

# ---------- pronunciació «a la catalana» (mateix sistema que el fitxer de rus)
CRESP = {'б': 'b', 'в': 'v', 'г': 'g', 'д': 'd', 'ж': 'j', 'з': 'z', 'к': 'k', 'л': 'l', 'м': 'm', 'н': 'n', 'п': 'p',
         'р': 'r', 'с': 's', 'т': 't', 'ф': 'f', 'х': 'kh', 'ц': 'ts', 'ч': 'tx', 'ш': 'x', 'щ': 'xx', 'й': 'i'}
RVOI = {'b': 'p', 'v': 'f', 'g': 'k', 'd': 't', 'z': 's', 'j': 'x'}
RVLESS = {'p': 'b', 'f': 'v', 'k': 'g', 't': 'd', 's': 'z', 'x': 'j'}
ACCV = {'a': 'Á', 'e': 'É', 'i': 'Í', 'o': 'Ó', 'u': 'Ú', 'y': 'Y'}

def ru_word_resp(word):
    plain = _norm(word).replace(ACC, '')
    units = _units(word)
    vs = [i for i, x in enumerate(units) if x[0] == 'V']
    s = _stress_index(units)
    if s is None and len(vs) == 1 and plain not in UNSTRESSED_WORDS: s = vs[0]
    segs = []  # list of (text, kind) kind C/V
    for k, x in enumerate(units):
        if x[0] == 'J':
            segs.append(['i', 'G']); continue
        if x[0] == 'C':
            t = CRESP[x[1]]
            soft = x[2] and x[1] not in ALWAYS_SOFT
            nxt = units[k + 1] if k + 1 < len(units) else None
            mark = ''
            if soft:
                if nxt and nxt[0] == 'V':
                    mark = 'SOFTV'
                else:
                    mark = "'"
            segs.append([t, 'C', mark]); continue
        _, b, st, _, after_hard = x
        prevsoft = k > 0 and (units[k - 1][0] == 'J' or (units[k - 1][0] == 'C' and units[k - 1][2]))
        if s is not None and k == s:
            v = ACCV[b]
        else:
            if b == 'o': v = 'a'
            elif b == 'a': v = 'i' if prevsoft and units[k - 1][0] != 'J' and k != len(units) - 1 else ('i' if (k > 0 and units[k - 1][0] == 'J') else 'a')
            elif b == 'e': v = 'y' if after_hard else 'i'
            else: v = b
        segs.append([v, 'V'])
    # assimilació de sonoritat
    for k in range(len(segs) - 1, -1, -1):
        if segs[k][1] != 'C': continue
        t = segs[k][0]
        nxt = segs[k + 1] if k + 1 < len(segs) else None
        if nxt is None or (nxt[1] == 'C' and nxt[0] in RVLESS and nxt[0] != 'x' or nxt and nxt[1] == 'C' and nxt[0] in ('kh', 'ts', 'tx', 'xx', 'f')):
            if t in RVOI: segs[k][0] = RVOI[t]
        elif nxt[1] == 'C' and nxt[0] in RVOI and nxt[0] != 'v':
            if t in RVLESS: segs[k][0] = RVLESS[t]
    # síl·labes: tall abans de l'última consonant d'un grup intervocàlic
    sylls = []; cur = ''; pend = []
    vidx = [i for i, sg in enumerate(segs) if sg[1] == 'V']
    stressed_syl = None
    for n, vi in enumerate(vidx):
        start = 0 if n == 0 else None
        if n > 0:
            prev_v = vidx[n - 1]
            cl = list(range(prev_v + 1, vi))
            cut = cl[-1] if cl else vi
            if len(cl) >= 2 and segs[cl[-1]][0] in ('r', 'l') and segs[cl[-2]][1] == 'C' and segs[cl[-2]][0] not in ('r', 'l', 'm', 'n', 'i'):
                cut = cl[-2]
            if cl and segs[cl[-1]][1] == 'G':
                cut = cl[-1]
            bounds_prev_end = cut
            sylls[-1] = (sylls[-1][0], bounds_prev_end)
            start = cut
        sylls.append((start, len(segs)))
        if s is not None and units and n == vs.index(s):
            stressed_syl = n
    for k, sg in enumerate(segs):
        if sg[1] == 'C' and len(sg) > 2 and sg[2] == 'SOFTV':
            nv = segs[k + 1][0] if k + 1 < len(segs) else ''
            sg[2] = '' if nv[:1].lower() in ('i', 'í') else 'i'
    def segtext(sg):
        return sg[0] + (sg[2] if sg[1] == 'C' and len(sg) > 2 else '')
    parts = []
    for n, (a, b) in enumerate(sylls):
        t = ''.join(segtext(sg) for sg in segs[a:b])
        # 'ss' per a s sorda entre vocals
        if a > 0 and segs[a][0] == 's' and segs[a][1] == 'C' and a + 1 < len(segs) and segs[a + 1][1] == 'V' and segs[a - 1][1] == 'V':
            t = 's' + t
        if n == stressed_syl:
            t = t.upper().replace("'", "'")
        parts.append(t)
    if not sylls:
        return ''.join(segtext(sg) for sg in segs)
    return '-'.join(parts)

def ru_resp(text):
    words = re.findall(r"[а-яёА-ЯЁ́\-]+", text)
    return ' '.join(ru_word_resp(w.replace('-', '')) for w in words)

# ---------- accent a partir de la pronunciació existent (MAJÚSCULES)
def stress_from_resp(word, resp):
    """Retorna la paraula russa amb accent (U+0301) deduït de la síl·laba en majúscules."""
    segs = [x for x in re.split(r"[-\s]", resp) if x]
    up = [i for i, sg in enumerate(segs) if re.sub(r"[^A-Za-zÁÉÍÓÚÀÈÒ]", '', sg) and re.sub(r"[^A-Za-zÁÉÍÓÚÀÈÒ]", '', sg).isupper()]
    if not up:
        return word
    idx = up[0]
    vpos = [i for i, ch in enumerate(word) if ch.lower() in VOW]
    if idx >= len(vpos) or 'ё' in word.lower():
        return word
    p = vpos[idx]
    return word[:p + 1] + ACC + word[p + 1:]

def ru_text_ipa_from_resp(text, resp):
    """IPA per a una entrada (pot tenir diverses paraules) usant la pronunciació existent per a l'accent."""
    words = re.findall(r"[а-яёА-ЯЁ\-]+", text)
    rw = [x for x in re.split(r"\s+", re.sub(r"[,;()]", ' ', resp or '')) if x and x not in ('/', '—')]
    res = []
    if len(words) == len(rw):
        for w, r in zip(words, rw):
            res.append(ru_word_ipa(stress_from_resp(w, r)))
    else:
        for w in words:
            res.append(ru_word_ipa(w))
    return '[' + ' '.join(res) + ']' if res else ''

if __name__ == '__main__':
    for k, v in [('がっこう', 0), ('せんせい', 0), ('コーヒー', 0), ('おもう', 1), ('きんえん', 0), ('しんぶん', 0),
                 ('ちゃわん', 0), ('きって', 0), ('ファイル', 0), ('ざっし', 0), ('いっしょ', 0), ('りょこう', 0), ('ずっと', 0)]:
        print(k, ja_ipa(k, bool(v)))
    for w in ['молоко́', 'хле́б', 'сестра́', 'де́вочка', 'чита́ть', 'учи́ться', 'язы́к', 'ёлка', 'объясня́ть', 'пого́да',
              'жена́', 'большо́й', 'сча́стье', 'здра́вствуйте', 'что', 'сего́дня', 'пла́тье', 'вокза́л', 'юбка', 'тетра́дь',
              'ру́сский', 'вчера́', 'лёгкий', 'мя́со', 'ме́сто', 'проща́ться', 'сле́дующий']:
        print(w, ru_ipa(w), ru_resp(w))
    print(stress_from_resp('человек', 'txi-la-VIÉK'), ru_text_ipa_from_resp('день рождения', 'DIÉN\' raj-DIÉ-ni-ii'))
