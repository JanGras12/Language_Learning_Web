#!/bin/sh
# Ordre de construcció de totes les dades de la web
cd /home/claude/web && python3 extract.py && python3 build_data.py && python3 add_levels.py && python3 ja_numbers.py && python3 build_ko.py && python3 build_zh.py && python3 build_de.py && python3 build_ar.py && python3 build_stats.py
