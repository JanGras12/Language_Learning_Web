"""Construeix site/data/ar.json a partir de /home/claude/langs/ar/*.txt i ar_gram*.txt."""
import json, glob, os
from collections import OrderedDict, Counter
from ar_lang import translit, ipa

D = '/home/claude/langs/ar/'
LV = ['A1', 'A2', 'B1']
FORMS = {'Q': 'I (quadr.)'}


def read(prefix, nf, must):
    """must: índexs de camps que no poden ser '—' (si ho són, la fila és una nota interna i es descarta)."""
    secs = OrderedDict(); bad = []
    for path in sorted(glob.glob(D + prefix + '*.txt')):
        sec = None; lv = None
        for line in open(path, encoding='utf8'):
            line = line.rstrip('\n')
            if not line.strip(): continue
            if line.startswith('@'): lv = line[1:].strip(); continue
            if line.startswith('#'): sec = line[1:].strip(); secs.setdefault(sec, []); continue
            f = [x.strip() for x in line.split('|')]
            if len(f) != nf: bad.append((path, line)); continue
            if any(f[i] in ('—', '') for i in must): continue
            if '(' in f[0] and prefix != 'c': continue  # notes internes
            secs[sec].append({'f': f, 'lv': lv})
    for b in bad: print('BAD', b[0][-7:], b[1][:70])
    return secs


def bare(w):
    """Clau sense vocals per detectar duplicats."""
    return ''.join(ch for ch in w.split('>')[0].split('*')[0] if not ('ً' <= ch <= 'ْ' or ch == 'ٰ'))


def main():
    nouns = read('n', 5, [2, 3, 4]); verbs = read('v', 8, [0, 1, 5, 6, 7]); adjs = read('a', 6, [3, 4, 5])
    advs = read('d', 4, [1, 2, 3]); conns = read('c', 5, [0, 1, 3, 4])
    stats = Counter()

    def dedupe(secs, kf, ci):
        seen = {}; out = OrderedDict()
        for s, rows in secs.items():
            keep = []
            for r in rows:
                k = kf(r)
                if k in seen:
                    o = seen[k]
                    have = [x.strip() for x in o['f'][ci].split(';')]
                    for x in r['f'][ci].split(';'):
                        if x.strip() and x.strip() not in have: have.append(x.strip())
                    o['f'][ci] = '; '.join(have); stats['dup'] += 1; continue
                seen[k] = r; keep.append(r)
            out[s] = keep
        return out, seen

    nouns, nk = dedupe(nouns, lambda r: r['f'][0].replace('*f','').replace('*m',''), 2)
    verbs, vk = dedupe(verbs, lambda r: r['f'][0], 5)
    adjs, ak = dedupe(adjs, lambda r: r['f'][0].split('>')[0], 3)
    advs, dk = dedupe(advs, lambda r: r['f'][0], 1)
    conns, ck = dedupe(conns, lambda r: r['f'][1], 0)
    C = lambda h, role: {'h': h, 'role': role}

    def vocab(sid, title, cols, secs, rowf):
        rows = []
        for s, rr in secs.items():
            if not rr: continue
            rows.append({'s': s})
            for r in rr:
                c, ip = rowf(r['f'])
                rows.append({'c': c, 'ipa': ip, 'lv': r['lv']})
        return {'id': sid, 'kind': 'vocab', 't': title, 'cols': cols, 'rows': rows}

    def nrow(f):
        w, pl, ca, ex, trx = f
        g = 'm'
        if w.endswith('*f'): w = w[:-2]; g = 'f'
        elif w.endswith('*m'): w = w[:-2]
        elif w.rstrip('ًٌٍَُِّْ').endswith('ة'): g = 'f'
        return [ca, w, translit(w), g, pl, ex, trx], ipa(w)

    def vrow(f):
        past, pres, mas, root, form, ca, ex, trx = f
        return [ca, past, translit(past, False), pres, mas, ' '.join(root), FORMS.get(form, form), ex, trx], ipa(past, False)

    def arow(f):
        m, pl, el, ca, ex, trx = f
        if '>' in m: m, fem = [x.strip() for x in m.split('>')]
        else: fem = m + 'َة'
        return [ca, m, translit(m), fem, pl, el, ex, trx], ipa(m)

    def drow(f):
        w, ca, ex, trx = f
        return [ca, w, translit(w), ex, trx], ipa(w)

    def crow(f):
        ca, w, tip, ex, trx = f
        return [ca, w, translit(w), tip, ex, trx], ipa(w)

    S = []
    S.append(vocab('nouns', {'ca': 'Noms', 'en': 'Nouns'},
                   [C('Català', 'tr'), C('Àrab', 'tl'), C('Translit.', 'pr'), C('Gènere', 'x'), C('Plural', 'tl2'), C('Frase (AR)', 'ex'), C('Frase (CA)', 'trx')], nouns, nrow))
    S.append(vocab('verbs', {'ca': 'Verbs', 'en': 'Verbs'},
                   [C('Català', 'tr'), C('Passat (ell)', 'tl'), C('Translit.', 'pr'), C('Present (ell)', 'tl2'), C('Màsdar', 'tl2'), C('Arrel', 'tl2'), C('Forma', 'x'), C('Frase (AR)', 'ex'), C('Frase (CA)', 'trx')], verbs, vrow))
    S.append(vocab('adjectives', {'ca': 'Adjectius', 'en': 'Adjectives'},
                   [C('Català', 'tr'), C('Masculí', 'tl'), C('Translit.', 'pr'), C('Femení', 'tl2'), C('Plural fracturat', 'tl2'), C('Elatiu', 'tl2'), C('Frase (AR)', 'ex'), C('Frase (CA)', 'trx')], adjs, arow))
    S.append(vocab('adverbs', {'ca': 'Adverbis', 'en': 'Adverbs'},
                   [C('Català', 'tr'), C('Àrab', 'tl'), C('Translit.', 'pr'), C('Frase (AR)', 'ex'), C('Frase (CA)', 'trx')], advs, drow))
    S.append(vocab('connectors', {'ca': 'Connectors', 'en': 'Connectors'},
                   [C('Català', 'tr'), C('Connector', 'tl'), C('Translit.', 'pr'), C('Tipus / regència', 'x'), C('Frase (AR)', 'ex'), C('Frase (CA)', 'trx')], conns, crow))

    G = OrderedDict()
    for path in ('ar_gram1.txt', 'ar_gram2.txt'):
        cur = None
        for line in open(path, encoding='utf8'):
            line = line.rstrip('\n')
            if not line.strip(): continue
            if line.startswith('==='):
                sid, ca, en = [x.strip() for x in line[3:].split('|')]
                cur = {'id': sid, 'kind': 'grammar', 't': {'ca': ca, 'en': en}, 'items': []}; G[sid] = cur; continue
            p = line.split('|')
            if p[0] == 'T': cur['items'].append(['T', p[2], p[1]])
            elif p[0] == 'P': cur['items'].append(['P', '|'.join(p[1:])])
            elif p[0] in ('H', 'R'): cur['items'].append([p[0], p[1:]])

    counts = {s['id']: sum(1 for r in s['rows'] if 'c' in r) for s in S}
    bylv = {s['id']: Counter(r['lv'] for r in s['rows'] if 'c' in r) for s in S}
    total = sum(counts.values())
    nm = {'nouns': 'Noms', 'verbs': 'Verbs', 'adjectives': 'Adjectius'}
    guide = [['G', "Àrab estàndard modern A1–B1: quadern d'estudi"],
             ['T', 'Contingut'],
             ['K', 'Recompte', f"Noms: {counts['nouns']}  ·  Verbs: {counts['verbs']}  ·  Adjectius: {counts['adjectives']}  ·  Adverbis: {counts['adverbs']}  ·  Connectors: {counts['connectors']}  ·  Total: {total}", ''],
             ['K', 'Per nivell', '  ·  '.join(nm[k] + ': ' + ' / '.join(f"{l} {bylv[k][l]}" for l in LV) for k in nm), 'Fes servir el selector de nivells de dalt per veure només el que vols estudiar.'],
             ['K', 'Quin àrab', "Àrab estàndard modern (fuṣḥā): la llengua escrita, dels mitjans i dels registres formals, comuna a tots els països àrabs. Per parlar al carrer caldrà, a més, un dialecte (egipci, llevantí, marroquí…).", ''],
             ['K', 'Com està organitzat', "Tot vocalitzat (amb harakat) i amb transliteració. Noms amb gènere i plural (sobretot els fracturats, que cal aprendre). Verbs amb passat, present, màsdar (nom d'acció), arrel i forma verbal (I–X). Adjectius amb femení, plural fracturat i elatiu (comparatiu).", ''],
             ['T', 'Pestanyes'],
             ['K', 'Alfabet i pronunciació', "Les 28 lletres amb les seves formes, les vocals (harakat), hamza, tāʾ marbūṭa, lletres solars i lunars, accent i dialectes.", ''],
             ['K', 'Conjugació', "Arrels i patrons, pronoms, passat, present, negació, futur, modes, imperatiu, les deu formes verbals, verbs dèbils, كَانَ, passiva, participis i condicionals.", ''],
             ['K', 'Gènere, nombre i casos', "Gènere, definició, possessius, demostratius, els tres casos, iḍāfa, dual, plurals sans i fracturats, díptots i إِنَّ.", ''],
             ['K', 'Adjectius i adverbis', "Concordança, colors, nisba, elatiu (comparatiu i superlatiu), formació d'adverbis i ḥāl.", ''],
             ['K', 'Preposicions', "Preposicions bàsiques, «tenir», lloc, temps i verbs amb preposició fixa.", ''],
             ['K', 'Números', "Xifres, 1–1.000.000, la concordança dels números, ordinals, l'hora, calendaris i preus.", ''],
             ['K', 'Oracions', "Oració nominal i verbal, «hi ha», preguntes, frases de supervivència, relatives, أَنْ/أَنَّ i estructures formals.", ''],
             ['T', 'Llegeix això abans de fiar-te del material'],
             ['K', 'Selecció i nivells', f"El quadern té {total} paraules triades per mi. Per a l'àrab no hi ha una llista oficial de vocabulari per nivells MECR tan establerta com les de l'alemany o el rus: els nivells són una estimació meva segons la freqüència i els temes habituals dels manuals.", ''],
             ['K', 'Vocals i formes', "He escrit a mà la vocalització, els plurals fracturats, els presents, els màsdars i les arrels. Poden contenir errors: si una forma et sembla estranya, comprova-la en un diccionari (Hans Wehr, Almaany.com, Lane).", ''],
             ['K', 'Plurals', "La columna Plural dels adjectius només dona el plural fracturat quan n'hi ha un d'habitual. Si hi ha «—», el plural és el regular: -ūna (persones, masculí), -āt (femení) o, per a coses, el femení singular.", ''],
             ['K', 'Transliteració i IPA', "Generades per programa a partir de les vocals escrites, en forma de pausa (sense la vocal de cas final), excepte els verbs, que es donen amb la forma de citació completa (kataba, yaktubu). No reflecteixen l'enllaç entre paraules (hamzat al-waṣl) ni la pronunciació dialectal.", ''],
             ['K', 'Traduccions i frases', "Escrites per mi, no revisades per un parlant nadiu. Les frases d'exemple porten totes les vocals, incloses les de cas, com als manuals.", ''],
             ['K', 'Dades que poden haver canviat', "Res d'aquest material depèn de dades en temps real.", '']]
    sheets = [{'id': 'guide', 'kind': 'guide', 't': {'ca': 'Guia', 'en': 'Guide'}, 'items': guide}, G['alphabet']] + S + \
             [G['conjugation'], G['cases'], G['adjadv'], G['prepositions'], G['numbers'], G['sentences']]
    out = {'id': 'ar', 'name': {'ca': 'Àrab', 'en': 'Arabic'}, 'native': 'العربية', 'levels': 'A1–B1', 'lvset': LV, 'dir': 'rtl', 'sheets': sheets}
    json.dump(out, open('site/data/ar.json', 'w'), ensure_ascii=False, separators=(',', ':'))
    print(counts, total, {k: dict(v) for k, v in bylv.items()}, dict(stats), os.path.getsize('site/data/ar.json') // 1024, 'KB')


if __name__ == '__main__':
    main()
