"""Japonès: treu «Nombres» i «Comptadors» de Noms i crea la pestanya «Números i comptadors»."""
import json

d = json.load(open('site/data/ja.json'))
nouns = next(s for s in d['sheets'] if s['id'] == 'nouns')
KEEP = {'すうじ', 'ばんごう', 'かず', 'はんぶん', 'ばい'}
moved, keep_rows, rows, cur = [], [], [], None
for r in nouns['rows']:
    if 's' in r:
        cur = r['s']
        if cur not in ('Nombres', 'Comptadors'): rows.append(r)
        continue
    if cur in ('Nombres', 'Comptadors'):
        (keep_rows if r['c'][1] in KEEP else moved).append(r)
    else:
        rows.append(r)
# els noms generals es queden a «Lògica, relacions i quantitats»
i = next(i for i, r in enumerate(rows) if r.get('s') == 'Lògica, relacions i quantitats') + 1
rows[i:i] = keep_rows
nouns['rows'] = rows

def T(lv, t): return ['T', t, lv]
def P(t): return ['P', t]
def H(*c): return ['H', list(c)]
def R(*c): return ['R', list(c)]

C = [H('Comptador', 'Per a', '1', '2', '3', '4', '5', '6', '7', '8', '9', '10', 'Quants?')]
def cnt(k, use, *r): C.append(R(k, use, *r))
cnt('〜つ', 'coses en general (natiu, fins a 10)', 'ひとつ', 'ふたつ', 'みっつ', 'よっつ', 'いつつ', 'むっつ', 'ななつ', 'やっつ', 'ここのつ', 'とお', 'いくつ')
cnt('〜人 (にん)', 'persones', 'ひとり', 'ふたり', 'さんにん', 'よにん', 'ごにん', 'ろくにん', 'ななにん / しちにん', 'はちにん', 'きゅうにん', 'じゅうにん', 'なんにん')
cnt('〜枚 (まい)', 'coses planes: paper, camises, plats', 'いちまい', 'にまい', 'さんまい', 'よんまい', 'ごまい', 'ろくまい', 'ななまい', 'はちまい', 'きゅうまい', 'じゅうまい', 'なんまい')
cnt('〜本 (ほん)', 'coses llargues: ampolles, llapis, paraigües', 'いっぽん', 'にほん', 'さんぼん', 'よんほん', 'ごほん', 'ろっぽん', 'ななほん', 'はっぽん', 'きゅうほん', 'じゅっぽん', 'なんぼん')
cnt('〜冊 (さつ)', 'llibres, llibretes', 'いっさつ', 'にさつ', 'さんさつ', 'よんさつ', 'ごさつ', 'ろくさつ', 'ななさつ', 'はっさつ', 'きゅうさつ', 'じゅっさつ', 'なんさつ')
cnt('〜匹 (ひき)', 'animals petits (gats, peixos)', 'いっぴき', 'にひき', 'さんびき', 'よんひき', 'ごひき', 'ろっぴき', 'ななひき', 'はっぴき', 'きゅうひき', 'じゅっぴき', 'なんびき')
cnt('〜個 (こ)', 'objectes petits i rodons', 'いっこ', 'にこ', 'さんこ', 'よんこ', 'ごこ', 'ろっこ', 'ななこ', 'はっこ', 'きゅうこ', 'じゅっこ', 'なんこ')
cnt('〜杯 (はい)', 'gots, tasses, bols', 'いっぱい', 'にはい', 'さんばい', 'よんはい', 'ごはい', 'ろっぱい', 'ななはい', 'はっぱい', 'きゅうはい', 'じゅっぱい', 'なんばい')
cnt('〜台 (だい)', 'màquines i vehicles', 'いちだい', 'にだい', 'さんだい', 'よんだい', 'ごだい', 'ろくだい', 'ななだい', 'はちだい', 'きゅうだい', 'じゅうだい', 'なんだい')
cnt('〜回 (かい)', 'vegades', 'いっかい', 'にかい', 'さんかい', 'よんかい', 'ごかい', 'ろっかい', 'ななかい', 'はっかい', 'きゅうかい', 'じゅっかい', 'なんかい')
cnt('〜階 (かい)', 'pisos d\'un edifici', 'いっかい', 'にかい', 'さんがい', 'よんかい', 'ごかい', 'ろっかい', 'ななかい', 'はっかい', 'きゅうかい', 'じゅっかい', 'なんがい')
cnt('〜歳 (さい)', 'anys d\'edat (20 = はたち)', 'いっさい', 'にさい', 'さんさい', 'よんさい', 'ごさい', 'ろくさい', 'ななさい', 'はっさい', 'きゅうさい', 'じゅっさい', 'なんさい')
cnt('〜足 (そく)', 'parells (sabates, mitjons)', 'いっそく', 'にそく', 'さんぞく', 'よんそく', 'ごそく', 'ろくそく', 'ななそく', 'はっそく', 'きゅうそく', 'じゅっそく', 'なんぞく')
cnt('〜着 (ちゃく)', 'vestits, peces de roba', 'いっちゃく', 'にちゃく', 'さんちゃく', 'よんちゃく', 'ごちゃく', 'ろくちゃく', 'ななちゃく', 'はっちゃく', 'きゅうちゃく', 'じゅっちゃく', 'なんちゃく')
cnt('〜軒 (けん)', 'cases, botigues', 'いっけん', 'にけん', 'さんげん', 'よんけん', 'ごけん', 'ろっけん', 'ななけん', 'はっけん', 'きゅうけん', 'じゅっけん', 'なんげん')
cnt('〜頭 (とう)', 'animals grans (vaques, cavalls)', 'いっとう', 'にとう', 'さんとう', 'よんとう', 'ごとう', 'ろくとう', 'ななとう', 'はっとう', 'きゅうとう', 'じゅっとう', 'なんとう')
cnt('〜羽 (わ)', 'ocells (i conills)', 'いちわ', 'にわ', 'さんわ / さんば', 'よんわ', 'ごわ', 'ろくわ', 'ななわ', 'はちわ', 'きゅうわ', 'じゅうわ', 'なんわ')

TIME = [H('Número', '〜時 (hora)', '〜分 (minut)', '〜日 (dia del mes)', '〜月 (mes)', '〜日間 / 〜か月 (durada)')]
for row in [('1', 'いちじ', 'いっぷん', 'ついたち', 'いちがつ', 'いちにち · いっかげつ'), ('2', 'にじ', 'にふん', 'ふつか', 'にがつ', 'ふつかかん · にかげつ'),
            ('3', 'さんじ', 'さんぷん', 'みっか', 'さんがつ', 'みっかかん · さんかげつ'), ('4', 'よじ', 'よんぷん', 'よっか', 'しがつ', 'よっかかん · よんかげつ'),
            ('5', 'ごじ', 'ごふん', 'いつか', 'ごがつ', 'いつかかん · ごかげつ'), ('6', 'ろくじ', 'ろっぷん', 'むいか', 'ろくがつ', 'むいかかん · ろっかげつ'),
            ('7', 'しちじ', 'ななふん', 'なのか', 'しちがつ', 'なのかかん · ななかげつ'), ('8', 'はちじ', 'はっぷん', 'ようか', 'はちがつ', 'ようかかん · はっかげつ'),
            ('9', 'くじ', 'きゅうふん', 'ここのか', 'くがつ', 'ここのかかん · きゅうかげつ'), ('10', 'じゅうじ', 'じゅっぷん', 'とおか', 'じゅうがつ', 'とおかかん · じゅっかげつ'),
            ('11', 'じゅういちじ', 'じゅういっぷん', 'じゅういちにち', 'じゅういちがつ', '—'), ('12', 'じゅうにじ', 'じゅうにふん', 'じゅうににち', 'じゅうにがつ', '—'),
            ('14', '—', 'じゅうよんぷん', 'じゅうよっか', '—', '—'), ('20', '—', 'にじゅっぷん', 'はつか', '—', 'はつかかん'),
            ('24', '—', 'にじゅうよんぷん', 'にじゅうよっか', '—', '—'), ('30', '—', 'さんじゅっぷん (= 半)', 'さんじゅうにち', '—', '—'),
            ('Quants?', 'なんじ', 'なんぷん', 'なんにち', 'なんがつ', 'なんにち · なんかげつ')]:
    TIME.append(R(*row))

items = [
    T('A1', '1. DUES SÈRIES DE NÚMEROS'),
    P("El japonès fa servir dues sèries: la sinojaponesa (いち, に, さん…), que serveix per a gairebé tot, i la nativa (ひとつ, ふたつ…), que només arriba a 10 i serveix per comptar coses sense comptador específic."),
    H('Número', 'Kanji', 'Sinojaponès', 'Natiu (〜つ)', 'Nota'),
    R('0', '零', 'れい / ゼロ', '—', 'Al telèfon i als preus es diu ゼロ o まる'),
    R('1', '一', 'いち', 'ひとつ', ''), R('2', '二', 'に', 'ふたつ', ''), R('3', '三', 'さん', 'みっつ', ''),
    R('4', '四', 'よん / し', 'よっつ', 'し sona com «mort» (死): s\'evita'), R('5', '五', 'ご', 'いつつ', ''),
    R('6', '六', 'ろく', 'むっつ', ''), R('7', '七', 'なな / しち', 'ななつ', 'なな és més clar'), R('8', '八', 'はち', 'やっつ', ''),
    R('9', '九', 'きゅう / く', 'ここのつ', 'く sona com «patiment» (苦)'), R('10', '十', 'じゅう', 'とお', ''),
    T('A1', '2. NÚMEROS GRANS'),
    P("Es construeixen per multiplicació: 二十 (2×10) = にじゅう, 三百 = さんびゃく. Com en xinès i en coreà, s'agrupen de 4 en 4 xifres: 万 (man) = 10.000; 億 (oku) = 100.000.000. 100.000 = 十万 (じゅうまん), 1.000.000 = 百万 (ひゃくまん)."),
    H('Número', 'Kanji', 'Lectura', 'Atenció'),
    R('11', '十一', 'じゅういち', ''), R('20', '二十', 'にじゅう', ''), R('100', '百', 'ひゃく', 'no いちひゃく'),
    R('300', '三百', 'さんびゃく', 'canvi h→b'), R('600', '六百', 'ろっぴゃく', 'canvi h→pp'), R('800', '八百', 'はっぴゃく', 'canvi h→pp'),
    R('1.000', '千', 'せん', 'no いちせん'), R('3.000', '三千', 'さんぜん', 'canvi s→z'), R('8.000', '八千', 'はっせん', ''),
    R('10.000', '一万', 'いちまん', 'aquí sí que cal いち'), R('100.000', '十万', 'じゅうまん', ''), R('1.000.000', '百万', 'ひゃくまん', ''),
    R('100.000.000', '一億', 'いちおく', ''),
    T('A1', '3. COMPTADORS (助数詞): COM FUNCIONEN'),
    P("Per comptar coses s'enganxa un COMPTADOR al número, triat segons la forma o el tipus de cosa. L'ordre més habitual és NOM + を/が + NÚMERO+COMPTADOR + VERB: りんごを三つ買いました (he comprat tres pomes); 学生が五人います (hi ha cinc estudiants)."),
    P("Moltes lectures canvien amb 1, 3, 6, 8 i 10 (consonant doble o h→b/p). La taula de sota les dona totes; les irregulars s'han d'aprendre de memòria."),
    T('A1', '4. TAULA DE COMPTADORS'),
] + C + [
    T('A2', "5. HORES, MINUTS, DIES I MESOS"),
] + TIME + [
    P("Dies del mes: de l'1 al 10, el 14, el 20 i el 24 tenen lectures natives especials (ついたち, ふつか, はつか…); la resta és número + にち."),
    T('A2', '6. ALTRES COMPTADORS ÚTILS'),
    H('Comptador', 'Ús', 'Exemple', 'Lectura', 'Català'),
    R('〜円 (えん)', 'iens', '千五百円', 'せんごひゃくえん', '1.500 iens'),
    R('〜年 (ねん)', 'any (data i durada)', '二〇二六年 · 三年間', 'にせんにじゅうろくねん · さんねんかん', 'l\'any 2026 · durant tres anys'),
    R('〜週間 (しゅうかん)', 'setmanes de durada', '二週間', 'にしゅうかん', 'dues setmanes'),
    R('〜度 (ど)', 'graus; vegades', '三十度 · もう一度', 'さんじゅうど · もういちど', '30 graus · una altra vegada'),
    R('〜番 (ばん)', 'número (ordre)', '三番', 'さんばん', 'el número 3'),
    R('〜番目 (ばんめ)', 'ordinals', '二番目', 'にばんめ', 'el segon'),
    R('〜倍 (ばい)', 'multiplicador', '二倍', 'にばい', 'el doble'),
    R('〜キロ / 〜メートル', 'quilos, quilòmetres / metres', '五キロ', 'ごキロ', '5 quilos / 5 km'),
    R('〜ページ', 'pàgines', '十ページ', 'じゅっページ', 'pàgina 10'),
    R('〜名 (めい)', 'persones (formal)', '三名様', 'さんめいさま', 'tres persones (al restaurant)'),
    T('B1', '7. PREGUNTES I EXPRESSIONS AMB XIFRES'),
    H('Expressió', 'Lectura', 'Català'),
    R('いくつ', 'ikutsu', 'quants? (coses); quants anys? (amb お)'),
    R('いくら', 'ikura', 'quant costa?'),
    R('何人', 'なんにん', 'quantes persones?'),
    R('〜くらい / 〜ぐらい', 'kurai / gurai', 'aproximadament'),
    R('〜ずつ', 'zutsu', 'cadascú, de … en …: 一つずつ (un per cap)'),
    R('〜も (amb xifra)', 'mo', 'ni més ni menys que: 三時間も (ni més ni menys que tres hores)'),
    R('〜しか + negació', 'shika', 'només: 千円しかない (només tinc mil iens)'),
    R('〜目 (め)', 'me', 'ordinal: 一つ目 (el primer), 三日目 (el tercer dia)'),
    T('A1', '8. VOCABULARI DE NÚMEROS I COMPTADORS'),
    H('Kana', 'Kanji', 'Romaji', 'Català', 'Frase (JP)', 'Frase (CA)'),
] + [R(r['c'][1], r['c'][2], r['c'][3], r['c'][0], r['c'][4], r['c'][5]) for r in moved]

sheet = {'id': 'numbers', 'kind': 'grammar', 't': {'ca': 'Números i comptadors', 'en': 'Numbers & counters'}, 'items': items}
ids = [s['id'] for s in d['sheets']]
d['sheets'].insert(ids.index('prepositions') + 1, sheet)
# guia
g = next(s for s in d['sheets'] if s['id'] == 'guide')['items']
for it in g:
    if it[0] == 'K' and it[1] == 'Recompte':
        n = sum(1 for r in nouns['rows'] if 'c' in r)
        import re
        it[2] = re.sub(r'Noms: \d+', f'Noms: {n}', it[2])
j = next(i for i, it in enumerate(g) if it[0] == 'K' and it[1] == 'Oracions')
g[j:j] = [['K', 'Números i comptadors', 'Les dues sèries de números, números grans, tots els comptadors amb les lectures irregulars, hores, minuts, dies i mesos. Els números i comptadors ja no surten a Noms.', '']]
json.dump(d, open('site/data/ja.json', 'w'), ensure_ascii=False, separators=(',', ':'))
print('moved', len(moved), 'kept', len(keep_rows))
