# Quadern d'Idiomes — estat
- Web: site/index.html + site/data/{ja,ru,ko,zh}.json. Artifact URL: https://claude.ai/artifact/3Yvc7nGuUBicy42JuBmZP3 (publish same file_path, files map data/*.json)
- Rebuild: ./rebuild.sh (extract→build_data→add_levels→ja_numbers→build_ko→build_zh)
- Korean data: /home/claude/langs/ko/*.txt (@A1 level markers, *irr markers), grammar ko_gram1/2.txt
- Chinese data: /home/claude/langs/zh/ (n*: hanzi|pinyin|MW|cat|frase|CA ; v*,a*,d*: hanzi|pinyin|cat|frase|CA ; c*: cat|hanzi|pinyin|tipus|frase|CA) ; grammar zh_gram*.txt ; build_zh.py
- Pending: English translations; German, Arabic.
- German: /home/claude/langs/de/ (n: "der X|plural|cat|ex|ca"; v: "inf|..." weak or "inf>3sg>prät>perfekt|..."; '@s' = sein; '·' separable; a: "*U" umlaut or "pos>comp>sup"); grammar de_gram1/2.txt; de_lang.py; build_de.py
- Stats tab: build_stats.py -> site/data/stats.json; app button #statsBtn, hash #stats
- Japanese numbers sheet: ja_numbers.py (moves Nombres/Comptadors out of Noms)
- Arabic: /home/claude/langs/ar/ (n "word[*f]|plural|ca|ex|trx"; v "past|present|masdar|root|form|ca|ex|trx"; a "masc[>fem]|pl|elative|ca|ex|trx"; d; c). ar_lang.py (translit/IPA from vocalized text, pausal), build_ar.py, ar_gram1/2.txt. App: Noto Naskh Arabic, [lang=ar] plaintext bidi, arw() wraps Arabic in grammar. v1 = 1,632 words.
