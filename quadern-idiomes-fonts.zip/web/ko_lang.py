"""Coreà: descomposició del hangul, regles de pronunciació, romanització revisada (RR), IPA i forma -아요/어요."""
import re

CHO = list('ㄱㄲㄴㄷㄸㄹㅁㅂㅃㅅㅆㅇㅈㅉㅊㅋㅌㅍㅎ')
JUNG = list('ㅏㅐㅑㅒㅓㅔㅕㅖㅗㅘㅙㅚㅛㅜㅝㅞㅟㅠㅡㅢㅣ')
JONG = [''] + list('ㄱㄲㄳㄴㄵㄶㄷㄹㄺㄻㄼㄽㄾㄿㅀㅁㅂㅄㅅㅆㅇㅈㅊㅋㅌㅍㅎ')

def is_h(c): return '가' <= c <= '힣'
def dec(c):
    n = ord(c) - 0xAC00
    return [CHO[n // 588], JUNG[(n % 588) // 28], JONG[n % 28]]
def comp(i, v, f=''):
    return chr(0xAC00 + CHO.index(i) * 588 + JUNG.index(v) * 28 + JONG.index(f))

# ---------------------------------------------------------------- pronunciació
NEUT = {'ㄱ': 'ㄱ', 'ㄲ': 'ㄱ', 'ㅋ': 'ㄱ', 'ㄳ': 'ㄱ', 'ㄺ': 'ㄱ', 'ㄴ': 'ㄴ', 'ㄵ': 'ㄴ', 'ㄶ': 'ㄴ', 'ㄷ': 'ㄷ', 'ㅅ': 'ㄷ', 'ㅆ': 'ㄷ',
        'ㅈ': 'ㄷ', 'ㅊ': 'ㄷ', 'ㅌ': 'ㄷ', 'ㅎ': 'ㄷ', 'ㄹ': 'ㄹ', 'ㄼ': 'ㄹ', 'ㄽ': 'ㄹ', 'ㄾ': 'ㄹ', 'ㅀ': 'ㄹ', 'ㄻ': 'ㅁ', 'ㅁ': 'ㅁ',
        'ㅂ': 'ㅂ', 'ㅍ': 'ㅂ', 'ㄿ': 'ㅂ', 'ㅄ': 'ㅂ', 'ㅇ': 'ㅇ', '': ''}
SPLIT = {'ㄳ': ('ㄱ', 'ㅅ'), 'ㄵ': ('ㄴ', 'ㅈ'), 'ㄶ': ('ㄴ', 'ㅎ'), 'ㄺ': ('ㄹ', 'ㄱ'), 'ㄻ': ('ㄹ', 'ㅁ'), 'ㄼ': ('ㄹ', 'ㅂ'),
         'ㄽ': ('ㄹ', 'ㅅ'), 'ㄾ': ('ㄹ', 'ㅌ'), 'ㄿ': ('ㄹ', 'ㅍ'), 'ㅀ': ('ㄹ', 'ㅎ'), 'ㅄ': ('ㅂ', 'ㅅ')}
ASP = {'ㄱ': 'ㅋ', 'ㄷ': 'ㅌ', 'ㅂ': 'ㅍ', 'ㅈ': 'ㅊ'}
TENSE = {'ㄱ': 'ㄲ', 'ㄷ': 'ㄸ', 'ㅂ': 'ㅃ', 'ㅅ': 'ㅆ', 'ㅈ': 'ㅉ'}
NASAL = {'ㄱ': 'ㅇ', 'ㄷ': 'ㄴ', 'ㅂ': 'ㅁ'}

def pron_word(w):
    """Retorna una llista de síl·labes pronunciades [inicial, vocal, final_neutralitzada]."""
    sy = [dec(c) + [False] for c in w if is_h(c)]
    n = len(sy)
    for k in range(n):
        i, v, f, _ = sy[k]
        nx = sy[k + 1] if k + 1 < n else None
        if nx is None:
            continue
        ni = nx[0]
        # ㅎ final
        if f in ('ㅎ', 'ㄶ', 'ㅀ'):
            rest = {'ㅎ': '', 'ㄶ': 'ㄴ', 'ㅀ': 'ㄹ'}[f]
            if ni in ASP:
                nx[0] = ASP[ni]; sy[k][2] = rest; continue
            if ni == 'ㅇ':
                sy[k][2] = ''
                if rest: nx[0] = rest
                continue
            if ni == 'ㄴ':
                sy[k][2] = rest or 'ㄴ'; continue
            if ni == 'ㅅ' and not rest:
                nx[3] = True; sy[k][2] = ''; continue
        # ㅎ inicial després d'oclusiva → aspirada
        if ni == 'ㅎ' and f and NEUT.get(f, f) in ('ㄱ', 'ㄷ', 'ㅂ') and f not in SPLIT:
            base = NEUT[f] if f not in ('ㅈ', 'ㅊ') else 'ㅈ'
            if f in ('ㅅ', 'ㅈ', 'ㅊ', 'ㅌ'): base = 'ㄷ' if f != 'ㅈ' else 'ㅈ'
            nx[0] = ASP.get(base, ASP.get(NEUT[f], 'ㅎ')); sy[k][2] = ''; continue
        if ni == 'ㅎ' and f in SPLIT and SPLIT[f][1] in ASP:
            a, b = SPLIT[f]; sy[k][2] = a; nx[0] = ASP[b]; continue
        # enllaç (연음)
        if ni == 'ㅇ' and f and f != 'ㅇ':
            if f in SPLIT:
                a, b = SPLIT[f]
                sy[k][2] = a; nx[0] = b
                if b == 'ㅅ': nx[3] = True
            else:
                sy[k][2] = ''; nx[0] = f
            # palatalització
            if nx[0] == 'ㄷ' and nx[1] == 'ㅣ': nx[0] = 'ㅈ'
            if nx[0] == 'ㅌ' and nx[1] == 'ㅣ': nx[0] = 'ㅊ'
            continue
    # neutralització de finals
    for s in sy:
        f = s[2]
        if f in SPLIT:
            a, b = SPLIT[f]
            s[2] = NEUT[b] if f in ('ㄺ', 'ㄻ', 'ㄿ') else NEUT[a]
        else:
            s[2] = NEUT.get(f, f)
    # assimilacions
    for k in range(n - 1):
        f = sy[k][2]; ni = sy[k + 1][0]
        if f in ('ㄱ', 'ㄷ', 'ㅂ'):
            if ni == 'ㄹ': sy[k + 1][0] = 'ㄴ'; ni = 'ㄴ'
            if ni in ('ㄴ', 'ㅁ'): sy[k][2] = NASAL[f]
            elif ni in TENSE: sy[k + 1][3] = True
        elif f in ('ㅁ', 'ㅇ') and ni == 'ㄹ':
            sy[k + 1][0] = 'ㄴ'
        elif f == 'ㄴ' and ni == 'ㄹ':
            sy[k][2] = 'ㄹ'
        elif f == 'ㄹ' and ni == 'ㄴ':
            sy[k + 1][0] = 'ㄹ'
    return sy

RR_I = {'ㄱ': 'g', 'ㄲ': 'kk', 'ㄴ': 'n', 'ㄷ': 'd', 'ㄸ': 'tt', 'ㄹ': 'r', 'ㅁ': 'm', 'ㅂ': 'b', 'ㅃ': 'pp', 'ㅅ': 's', 'ㅆ': 'ss',
        'ㅇ': '', 'ㅈ': 'j', 'ㅉ': 'jj', 'ㅊ': 'ch', 'ㅋ': 'k', 'ㅌ': 't', 'ㅍ': 'p', 'ㅎ': 'h'}
RR_V = dict(zip(JUNG, 'a ae ya yae eo e yeo ye o wa wae oe yo u wo we wi yu eu ui i'.split()))
RR_F = {'': '', 'ㄱ': 'k', 'ㄴ': 'n', 'ㄷ': 't', 'ㄹ': 'l', 'ㅁ': 'm', 'ㅂ': 'p', 'ㅇ': 'ng'}
UNTENSE = {v: k for k, v in TENSE.items()}

def rr_word(w):
    """Romanització revisada (reflecteix assimilacions, no la tensió)."""
    sy = pron_word(w)
    out = ''
    for k, (i, v, f, tz) in enumerate(sy):
        ii = i
        if ii == 'ㄹ' and k > 0 and sy[k - 1][2] == 'ㄹ': c = 'l'
        else: c = RR_I[ii]
        if k > 0 and out and c and out[-1] in 'aeiouyw' and False: pass
        out += c + RR_V[v] + RR_F[f]
    return out

def romanize(text):
    parts = re.split(r'(\s+|[^가-힣\s]+)', text)
    return ''.join(rr_word(p) if p and is_h(p[0]) else p for p in parts).strip()

IPA_I = {'ㄱ': 'k', 'ㄲ': 'k͈', 'ㄴ': 'n', 'ㄷ': 't', 'ㄸ': 't͈', 'ㄹ': 'ɾ', 'ㅁ': 'm', 'ㅂ': 'p', 'ㅃ': 'p͈', 'ㅅ': 's', 'ㅆ': 's͈',
         'ㅇ': '', 'ㅈ': 'tɕ', 'ㅉ': 't͈ɕ', 'ㅊ': 'tɕʰ', 'ㅋ': 'kʰ', 'ㅌ': 'tʰ', 'ㅍ': 'pʰ', 'ㅎ': 'h'}
VOICED = {'ㄱ': 'ɡ', 'ㄷ': 'd', 'ㅂ': 'b', 'ㅈ': 'dʑ'}
IPA_V = dict(zip(JUNG, 'a ɛ ja jɛ ʌ e jʌ je o wa wɛ we jo u wʌ we wi ju ɯ ɰi i'.split()))
IPA_F = {'': '', 'ㄱ': 'k̚', 'ㄴ': 'n', 'ㄷ': 't̚', 'ㄹ': 'l', 'ㅁ': 'm', 'ㅂ': 'p̚', 'ㅇ': 'ŋ'}

def ipa_word(w):
    sy = pron_word(w); out = ''
    for k, (i, v, f, tz) in enumerate(sy):
        if tz and i in TENSE: i = TENSE[i]
        prev_f = sy[k - 1][2] if k > 0 else None
        voiced_ctx = k > 0 and prev_f in ('', 'ㄴ', 'ㄹ', 'ㅁ', 'ㅇ')
        if i == 'ㄹ':
            c = 'l' if prev_f == 'ㄹ' else ('ɾ' if k > 0 else 'ɾ')
        elif i in VOICED and voiced_ctx and not tz:
            c = VOICED[i]
        else:
            c = IPA_I[i]
        if i in ('ㅅ', 'ㅆ') and v in ('ㅣ', 'ㅑ', 'ㅕ', 'ㅛ', 'ㅠ', 'ㅒ', 'ㅖ', 'ㅟ'): c = 'ɕ' if i == 'ㅅ' else 'ɕ͈'
        if i == 'ㅎ' and voiced_ctx: c = 'ɦ'
        vv = IPA_V[v]
        if v == 'ㅢ' and (k > 0 or i != 'ㅇ'): vv = 'i'
        if v == 'ㅖ' and i not in ('ㅇ', 'ㄹ'): vv = 'e'
        out += c + vv + IPA_F[f]
    return out

def ipa(text):
    ws = re.findall(r'[가-힣]+', text)
    return '[' + ' '.join(ipa_word(w) for w in ws) + ']' if ws else ''

# ---------------------------------------------------------------- conjugació -아요/어요
IRR_NAMES = {'ㅂ': 'ㅂ irr.', 'ㄷ': 'ㄷ irr.', 'ㅅ': 'ㅅ irr.', 'ㅎ': 'ㅎ irr.', '르': '르 irr.'}
EU_REG = {'따르다', '치르다', '들르다'}

def bright(v): return v in ('ㅏ', 'ㅗ', 'ㅑ')

def haeyo(word, irr=None):
    """word: forma de diccionari (pot tenir diverses paraules; es conjuga l'última)."""
    if ' ' in word:
        a, b = word.rsplit(' ', 1); h, t = haeyo(b, irr); return a + ' ' + h, t
    if word == '푸르다': return '푸르러요', '러 irr.'
    if word.endswith('이다') and len(word) > 2:
        st = word[:-2]; last = dec(st[-1])
        return st + ('이에요' if last[2] else '예요'), 'regular (이다)'
    st = word[:-1]
    if st.endswith('하'):
        return st[:-1] + '해요', '하다'
    i, v, f = dec(st[-1]); pre = st[:-1]
    prevv = dec(pre[-1])[1] if pre and is_h(pre[-1]) else None
    if f:
        if irr == 'ㅂ' and f == 'ㅂ':
            base = pre + comp(i, v)
            if st in ('돕', '곱'): return base + '와요', IRR_NAMES['ㅂ']
            return base + '워요', IRR_NAMES['ㅂ']
        if irr == 'ㄷ' and f == 'ㄷ':
            return pre + comp(i, v, 'ㄹ') + ('아요' if bright(v) else '어요'), IRR_NAMES['ㄷ']
        if irr == 'ㅅ' and f == 'ㅅ':
            return pre + comp(i, v) + ('아요' if bright(v) else '어요'), IRR_NAMES['ㅅ']
        if irr == 'ㅎ' and f == 'ㅎ':
            nv = {'ㅏ': 'ㅐ', 'ㅓ': 'ㅐ', 'ㅑ': 'ㅒ', 'ㅕ': 'ㅖ'}.get(v, 'ㅐ')
            if st.endswith('어떻'): return pre + comp(i, 'ㅐ') + '요', IRR_NAMES['ㅎ']
            return pre + comp(i, nv) + '요', IRR_NAMES['ㅎ']
        typ = 'ㄹ' if f == 'ㄹ' else 'regular'
        return st + ('아요' if bright(v) else '어요'), typ
    # sense final
    if v == 'ㅡ':
        if i == 'ㄹ' and word not in EU_REG and pre:
            pi, pv, pf = dec(pre[-1])
            return pre[:-1] + comp(pi, pv, 'ㄹ') + ('라요' if bright(pv) else '러요'), IRR_NAMES['르']
        nv = 'ㅏ' if (prevv and bright(prevv)) else 'ㅓ'
        return pre + comp(i, nv) + '요', '으'
    m = {'ㅏ': 'ㅏ', 'ㅓ': 'ㅓ', 'ㅕ': 'ㅕ', 'ㅐ': 'ㅐ', 'ㅔ': 'ㅔ', 'ㅗ': 'ㅘ', 'ㅜ': 'ㅝ', 'ㅣ': 'ㅕ', 'ㅚ': 'ㅙ'}
    if v in m:
        return pre + comp(i, m[v]) + '요', 'regular'
    return st + '어요', 'regular'

if __name__ == '__main__':
    for w in ['한국어', '감사합니다', '신라', '종로', '좋다', '많이', '읽다', '같이', '국립', '설날', '먹는', '입학', '닭', '앉아요', '꽃이', '밥', '부엌', '십육', '학교', '한글', '맛있어요', '없어요']:
        print(w, romanize(w), ipa(w))
    for w, irr in [('가다', None), ('오다', None), ('마시다', None), ('듣다', 'ㄷ'), ('돕다', 'ㅂ'), ('춥다', 'ㅂ'), ('낫다', 'ㅅ'), ('하얗다', 'ㅎ'), ('빨갛다', 'ㅎ'),
                   ('모르다', None), ('바쁘다', None), ('쓰다', None), ('살다', None), ('먹다', None), ('공부하다', None), ('되다', None), ('쉬다', None),
                   ('일반적이다', None), ('키가 크다', None), ('세다', None), ('보내다', None), ('켜다', None), ('배우다', None), ('따르다', None), ('예의 바르다', None)]:
        print(w, haeyo(w, irr))
