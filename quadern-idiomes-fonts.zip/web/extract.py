"""Converteix els Excel (japonès, rus) al format JSON de la web."""
import openpyxl, json, sys
from ipa import ja_ipa, ru_text_ipa_from_resp

SEC, HEAD = '002E75B6', '001F3864'

def cellv(v):
    if v is None: return ''
    if isinstance(v, float) and v.is_integer(): v = int(v)
    return str(v).strip()

def merged_starts(ws):
    return {m.min_row for m in ws.merged_cells.ranges if m.min_col == 1 and m.max_col > 1 and m.min_row == m.max_row}

def trim(cells):
    while cells and cells[-1] == '': cells.pop()
    return cells

def grammar(ws):
    ms = merged_starts(ws); out = []
    for r in range(1, ws.max_row + 1):
        cells = trim([cellv(ws.cell(r, c).value) for c in range(1, ws.max_column + 1)])
        if not cells: continue
        fill = ws.cell(r, 1).fill.fgColor.rgb
        if fill == SEC: out.append(['T', cells[0]])
        elif fill == HEAD: out.append(['H', cells])
        elif r in ms or (len(cells) == 1 and len(cells[0]) > 60): out.append(['P', cells[0]])
        else: out.append(['R', cells])
    return out

def guide(ws):
    out = []
    for r in range(1, ws.max_row + 1):
        cells = trim([cellv(ws.cell(r, c).value) for c in range(1, 4)])
        if not cells: continue
        if r == 1: out.append(['G', cells[0]]); continue
        if ws.cell(r, 1).fill.fgColor.rgb == SEC: out.append(['T', cells[0]])
        else: out.append(['K'] + cells + [''] * (3 - len(cells)))
    return out

def table(ws, drop_last=False, ipa=None):
    """Taula amb seccions (vocabulari o alfabet). Retorna capçalera i files."""
    head = trim([cellv(c.value) for c in ws[1]])
    if drop_last and head and head[-1].startswith('Après'): head = head[:-1]
    n = len(head); rows = []
    for r in range(2, ws.max_row + 1):
        cells = [cellv(ws.cell(r, c).value) for c in range(1, n + 1)]
        if not any(cells): continue
        if ws.cell(r, 1).fill.fgColor.rgb == SEC and not any(cells[1:]):
            rows.append({'s': cells[0]}); continue
        row = {'c': cells}
        if ipa: row['ipa'] = ipa(cells)
        rows.append(row)
    return head, rows

ROLE = {'Català': 'tr', 'Frase (CA)': 'trx'}

def vocab(ws, ipa):
    head, rows = table(ws, drop_last=True, ipa=ipa)
    cols = [{'h': h, 'role': ROLE.get(h, 'tl' if i == 1 else 'x')} for i, h in enumerate(head)]
    for i, h in enumerate(head):
        if h.startswith('Frase (') and h != 'Frase (CA)': cols[i]['role'] = 'ex'
        if h in ('Pronunciació', 'Romaji', 'Pronunciació (imperf. / perf.)'): cols[i]['role'] = 'pr'
        if h in ('Kanji', 'Perfectiu'): cols[i]['role'] = 'tl2'
    return {'cols': cols, 'rows': rows}

def build_ja(path):
    wb = openpyxl.load_workbook(path)
    def ip(verb):
        return lambda c: ja_ipa(c[1], verb)
    S = []
    S.append({'id': 'guide', 'kind': 'guide', 'items': guide(wb['Guia'])})
    h, rows = table(wb['Kana'])
    S.append({'id': 'alphabet', 'kind': 'table', 'title': 'Kana', 'cols': [{'h': x} for x in h], 'rows': rows})
    for sid, name in [('nouns', 'Noms'), ('verbs', 'Verbs'), ('adjectives', 'Adjectius'), ('adverbs', 'Adverbis'), ('connectors', 'Connectors')]:
        d = vocab(wb[name], ip(sid == 'verbs')); d.update(id=sid, kind='vocab', title=name); S.append(d)
    for sid, name in [('conjugation', 'Conjugació'), ('cases', 'Partícules'), ('adjadv', 'Adjectius i adverbis'),
                      ('prepositions', 'Preposicions'), ('sentences', 'Oracions')]:
        S.append({'id': sid, 'kind': 'grammar', 'title': name, 'items': grammar(wb[name])})
    return S

def ru_ip(word_col, resp_col):
    def f(c):
        words = c[word_col]; resp = c[resp_col]
        if word_col == 1 and len(c) > 2 and c[2] and c[2] != '—' and '/' in resp:  # verbs: imperf / perf
            a, b = [x.strip() for x in resp.split('/', 1)]
            return ru_text_ipa_from_resp(c[1], a) + ' / ' + ru_text_ipa_from_resp(c[2], b)
        return ru_text_ipa_from_resp(words, resp)
    return f

def build_ru(path):
    wb = openpyxl.load_workbook(path)
    S = []
    S.append({'id': 'guide', 'kind': 'guide', 'items': guide(wb['Guia'])})
    h, rows = table(wb['Alfabet'])
    S.append({'id': 'alphabet', 'kind': 'table', 'title': 'Alfabet', 'cols': [{'h': x} for x in h], 'rows': rows})
    spec = [('nouns', 'Noms', 3), ('verbs', 'Verbs', 3), ('adjectives', 'Adjectius', 3), ('adverbs', 'Adverbis', 2), ('connectors', 'Connectors', 2)]
    for sid, name, rc in spec:
        d = vocab(wb[name], ru_ip(1, rc)); d.update(id=sid, kind='vocab', title=name); S.append(d)
    for sid, name in [('conjugation', 'Conjugació'), ('cases', 'Casos'), ('adjadv', 'Adjectius i adverbis'),
                      ('prepositions', 'Preposicions'), ('sentences', 'Oracions')]:
        S.append({'id': sid, 'kind': 'grammar', 'title': name, 'items': grammar(wb[name])})
    return S

if __name__ == '__main__':
    ja = build_ja('/home/claude/Japones_A1-B2.xlsx')
    ru = build_ru('/mnt/user-data/attachments/72a36073-385f-5e57-9bd4-5b241f591610/c9f3ec90-Rus_A1-B1_definitiu.xlsx')
    json.dump(ja, open('raw_ja.json', 'w'), ensure_ascii=False)
    json.dump(ru, open('raw_ru.json', 'w'), ensure_ascii=False)
    for name, S in [('ja', ja), ('ru', ru)]:
        print(name, [(s['id'], len(s.get('rows', s.get('items', [])))) for s in S])
