"""Afegeix nivell (lv) a cada fila de vocabulari i a cada secció de gramàtica del rus i del japonès."""
import json, re
from collections import Counter

LV = ['A1', 'A2', 'B1', 'B2']

def sec_level(name):
    m = re.search(r'\b(A1|A2|B1|B2)\b', name)
    return m.group(1) if m else None

# ---------------------------------------------------------------- RUS
def ru():
    d = json.load(open('site/data/ru.json'))
    L = {}
    for line in open('levels_ru.txt'):
        k, v = line.split(':', 1); L[k] = ' ' + v.strip() + ' '
    def lv(w):
        w = w.strip()
        for k in ('A1', 'A2'):
            if ' ' + w + ' ' in L[k]: return k
        return 'B1'
    G = {'conjugation': {0: 'A1', 10: 'A1', 16: 'A2', 29: 'A1', 41: 'A1', 55: 'A2', 65: 'A2', 74: 'A2', 83: 'B1', 90: 'A2'},
         'cases': {0: 'A1', 8: 'A1', 20: 'A2', 35: 'A2', 41: 'A1', 53: 'B1', 68: 'B1'},
         'adjadv': {0: 'A2', 8: 'A2', 15: 'A1', 24: 'B1', 31: 'A2', 49: 'A2', 57: 'A1', 65: 'B1', 71: 'B1'},
         'prepositions': {0: 'A1', 5: 'A1', 10: 'A2', 17: 'A2', 31: 'B1', 36: 'B1', 45: 'A1', 51: 'A2', 55: 'A2', 70: 'B1'},
         'sentences': {0: 'A1'}}
    apply(d, lv, G, ['A1', 'A2', 'B1'])
    json.dump(d, open('site/data/ru.json', 'w'), ensure_ascii=False, separators=(',', ':'))

# ---------------------------------------------------------------- JAPONÈS
N5 = set('日一国人年大十二本中長出三時行見月分後前生五間上東四今金九入学高円子外八六下来気小七山話女北午百書先名川千水半男西電校語土木聞食車何南万毎白天母火右読友左休父雨')
N4 = set('会同事自社発者地業方新場員立開手力問代明動京目通言理体田主題意不作用度強公持野以思家世多正安院心界教文元重近考画海売知道集別物使品計死特私始朝運終台広住真有口少町料工建空急止送切転研足究楽起着店病質待試族銀早映親験英医仕去味写字答夜音注帰古歌買悪図週室歩風紙黒花春赤青館屋色走秋夏習駅洋旅服夕借曜飲肉貸堂鳥飯勉冬昼茶弟牛魚兄犬妹姉漢耳目足頭顔体')
A1_KANA = set('''わたし あなた かれ かのじょ これ それ あれ どれ この その あの どの ここ そこ あそこ どこ こちら そちら あちら どちら だれ なに なん いつ どう いくら いくつ どうして なぜ もの こと ところ とき ひと かた ほう うち いえ へや ドア まど テーブル いす ベッド テレビ ペン ノート かばん くつ ふく シャツ ズボン スカート コート めがね とけい でんわ ケータイ パン ごはん たまご にく さかな やさい くだもの りんご バナナ みず おちゃ コーヒー ジュース ミルク ビール おかね カード きっぷ バス タクシー でんしゃ ホテル レストラン デパート スーパー コンビニ トイレ えき みせ がっこう せんせい がくせい ともだち かぞく ちち はは あに あね おとうと いもうと おとうさん おかあさん おにいさん おねえさん こども おとな おとこ おんな あさ ひる よる きょう あした きのう いま まいにち しゅうまつ はる なつ あき ふゆ あめ ゆき てんき いぬ ねこ はな き やま うみ かわ まち くに なまえ しごと べんきょう しゅくだい テスト ほん しんぶん ざっし えいが おんがく うた スポーツ サッカー テニス ある いる する くる いく みる きく はなす よむ かく たべる のむ ねる おきる すむ かう うる まつ あう わかる できる すき きらい いい よい わるい おおきい ちいさい たかい やすい ひくい ながい みじかい あたらしい ふるい あつい さむい つめたい あたたかい おいしい まずい たのしい むずかしい やさしい おもしろい いそがしい ひま げんき しずか にぎやか きれい とても すこし たくさん もう まだ また いつも よく ときどき ちょっと ぜんぶ みんな はい いいえ'''.split())

def ja():
    d = json.load(open('site/data/ja.json'))
    freq = Counter()
    for s in d['sheets']:
        if s['kind'] == 'vocab':
            for r in s['rows']:
                if 'c' in r and not r['c'][2].startswith('('):
                    freq.update(set(re.findall(r'[一-鿿]', r['c'][2])))
    OV = {}
    for line in open('levels_ja_override.txt'):
        k, v = line.split(':', 1)
        for w in v.split():
            OV.setdefault(w, k)
    def lv_row(c, sid):
        kana, kanji = c[1].strip('〜～ '), c[2]
        kj = kanji.strip('()')
        if kj in OV: return OV[kj]
        K = set(re.findall(r'[一-鿿]', kanji)) if not kanji.startswith('(') else set()
        if kana in A1_KANA and (not K or K <= N5 | N4): return 'A1'
        if K:
            if K <= N5: return 'A1' if len(kana) <= 3 else 'A2'
            if K <= N5 | N4: return 'A2' if len(kana) <= 5 else 'B1'
            mn = min(freq[k] for k in K)
            rare = sum(1 for k in K if k not in N5 | N4)
            if mn >= 3 and rare <= 1: return 'B1'
            if mn >= 8: return 'B1'
            return 'B2'
        # sense kanji habitual
        kat = re.fullmatch(r'[゠-ヿー]+', kana)
        n = len(kana)
        if kat: return 'A2' if n <= 4 else 'B1'
        if re.fullmatch(r'(..)\1|(...)\2', kana): return 'B1' if sid != 'adverbs' else 'B2'  # mimètics
        if n <= 3: return 'A2'
        return 'B1'
    G = {'conjugation': {0: 'A1', 10: 'A2', 28: 'A2', 57: 'A1', 73: 'A2', 91: 'A2', 108: 'B1', 127: 'A2', 138: 'B1', 149: 'B1', 163: 'B1', 174: 'B1', 180: 'B2'},
         'cases': {0: 'A1', 5: 'A1', 26: 'A2', 42: 'B1', 57: 'A2', 66: 'A2'},
         'adjadv': {0: 'A1', 15: 'A1', 24: 'A1', 39: 'B1', 53: 'A2', 62: 'A2', 71: 'B1'},
         'prepositions': {0: 'A1', 5: 'A1', 11: 'A1', 33: 'A2', 47: 'B2', 78: 'B1'},
         'sentences': {0: 'A1', 28: 'B1', 78: 'B1', 85: 'A2'}}
    apply(d, None, G, ['A1', 'A2', 'B1', 'B2'], ja_row=lv_row)
    json.dump(d, open('site/data/ja.json', 'w'), ensure_ascii=False, separators=(',', ':'))

def apply(d, lvfn, G, lvset, ja_row=None):
    d['lvset'] = lvset
    stats = {}
    for s in d['sheets']:
        if s['kind'] == 'vocab':
            cur = None
            for r in s['rows']:
                if 's' in r: cur = sec_level(r['s']); continue
                if cur: r['lv'] = cur
                elif ja_row: r['lv'] = ja_row(r['c'], s['id'])
                else: r['lv'] = lvfn(r['c'][1])
                stats.setdefault(s['id'], Counter())[r['lv']] += 1
        if s['kind'] == 'grammar' and s['id'] in G:
            for i, it in enumerate(s['items']):
                if it[0] == 'T' and i in G[s['id']]:
                    if len(it) == 2: it.append(G[s['id']][i])
                    else: it[2] = G[s['id']][i]
    print(d['id'], {k: dict(v) for k, v in stats.items()})
    g = next(x for x in d['sheets'] if x['id'] == 'guide')['items']
    txt = '  ·  '.join({'nouns': 'Noms', 'verbs': 'Verbs', 'adjectives': 'Adjectius'}[k] + ': ' + ' / '.join(f"{l} {stats[k].get(l, 0)}" for l in lvset) for k in ('nouns', 'verbs', 'adjectives'))
    note = ("Nivells per paraula: estimació automàtica. Connectors i estructures: segons el bloc de nivell. "
            + ("Japonès: segons el nivell JLPT dels kanji de cada paraula (N5≈A1, N4≈A2), la freqüència del kanji dins d'aquest vocabulari i una llista de paraules bàsiques escrita per mi; no és la llista oficial (el JLPT no en publica)."
               if d['id'] == 'ja' else
               "Rus: llistes A1 i A2 escrites per mi a partir del meu coneixement del vocabulari bàsic (inspirat en el ТРКИ elemental i bàsic); la resta s'ha marcat B1. No he pogut consultar el «лексический минимум» oficial."))
    i = next(i for i, it in enumerate(g) if it[0] == 'K' and it[1] == 'Recompte')
    g[i + 1:i + 1] = [['K', 'Per nivell', txt, "Fes servir el selector de nivells de dalt per veure només el que vols estudiar."]]
    j = next(i for i, it in enumerate(g) if it[0] == 'K' and it[1].startswith('Dades que poden'))
    g[j:j] = [['K', 'Nivells A1–B2', note, '']]

if __name__ == '__main__':
    ru(); ja()
