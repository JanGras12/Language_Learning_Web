"""Àrab: transliteració (estil DIN/ALA-LC simplificat) i IPA a partir del text vocalitzat."""
import re

CONS = {'ب': ('b', 'b'), 'ت': ('t', 't'), 'ث': ('th', 'θ'), 'ج': ('j', 'dʒ'), 'ح': ('ḥ', 'ħ'), 'خ': ('kh', 'x'), 'د': ('d', 'd'),
        'ذ': ('dh', 'ð'), 'ر': ('r', 'r'), 'ز': ('z', 'z'), 'س': ('s', 's'), 'ش': ('sh', 'ʃ'), 'ص': ('ṣ', 'sˤ'), 'ض': ('ḍ', 'dˤ'),
        'ط': ('ṭ', 'tˤ'), 'ظ': ('ẓ', 'ðˤ'), 'ع': ('ʿ', 'ʕ'), 'غ': ('gh', 'ɣ'), 'ف': ('f', 'f'), 'ق': ('q', 'q'), 'ك': ('k', 'k'),
        'ل': ('l', 'l'), 'م': ('m', 'm'), 'ن': ('n', 'n'), 'ه': ('h', 'h'), 'و': ('w', 'w'), 'ي': ('y', 'j'), 'ء': ('ʾ', 'ʔ'),
        'أ': ('ʾ', 'ʔ'), 'إ': ('ʾ', 'ʔ'), 'ؤ': ('ʾ', 'ʔ'), 'ئ': ('ʾ', 'ʔ'), 'ة': ('t', 't')}
SUN = set('تثدذرزسشصضطظلن')
FATHA, KASRA, DAMMA, SUKUN, SHADDA = 'َ', 'ِ', 'ُ', 'ْ', 'ّ'
TAN = {'ً': 'an', 'ٍ': 'in', 'ٌ': 'un'}
DAGGER = 'ٰ'

def _word(w):
    """Retorna (translit, ipa) d'una paraula vocalitzada."""
    T, I = [], []  # llistes d'unitats
    i = 0; n = len(w)
    sun_skip = [False]
    # article
    if w.startswith('ال') or w.startswith('ٱل'):
        rest = w[2:]
        first = rest[:1]
        if first in SUN and SHADDA in rest[1:3]:
            t, p = CONS[first]
            T.append('a' + t + '-'); I.append('a'); sun_skip[0] = True
        else:
            T.append('al-'); I.append('al')
        i = 2
        w2 = w
    def nxt_marks(j):
        m = ''
        while j < n and w[j] in (FATHA, KASRA, DAMMA, SUKUN, SHADDA, DAGGER) or (j < n and w[j] in TAN):
            m += w[j]; j += 1
        return m, j
    last_v = ''
    while i < n:
        c = w[i]
        if c == 'آ':
            T.append('ʾā' if T and not T[-1].endswith('-') else 'ā'); I.append('ʔaː'); last_v = 'a'; i += 1; continue
        if c in 'اٱ':
            marks, j = nxt_marks(i + 1)
            if last_v == 'a' and not any(x in marks for x in (FATHA, KASRA, DAMMA)):
                T[-1] = T[-1] + 'ā' if T and T[-1].endswith('a') is False else T[-1]
                if T and T[-1].endswith('a'): T[-1] = T[-1][:-1] + 'ā'; I[-1] = I[-1][:-1] + 'aː'
                last_v = 'A'; i = j; continue
            if last_v == 'tan':
                i = j; continue
            # alif inicial (hamzat al-wasl) o amb vocal
            v = 'a' if FATHA in marks else 'i' if KASRA in marks else 'u' if DAMMA in marks else ''
            if v: T.append(v); I.append(v); last_v = v
            i = j; continue
        if c == 'ى':
            if last_v == 'tan' and T and T[-1].endswith('an'):
                T[-1] = T[-1][:-2] + 'ā'; I[-1] = I[-1][:-2] + 'aː'; last_v = 'A'; i += 1; continue
            if T and T[-1].endswith('a'): T[-1] = T[-1][:-1] + 'ā'; I[-1] = I[-1][:-1] + 'aː'
            else: T.append('ā'); I.append('aː')
            last_v = 'A'; i += 1; continue
        if c in CONS:
            marks, j = nxt_marks(i + 1)
            t, p = CONS[c]
            # vocal llarga amb و / ي
            if c == 'و' and last_v == 'u' and not any(x in marks for x in (FATHA, KASRA, DAMMA, SHADDA)):
                T[-1] = T[-1][:-1] + 'ū'; I[-1] = I[-1][:-1] + 'uː'; last_v = 'U'; i = j; continue
            if c == 'ي' and last_v == 'i' and not any(x in marks for x in (FATHA, KASRA, DAMMA, SHADDA)):
                T[-1] = T[-1][:-1] + 'ī'; I[-1] = I[-1][:-1] + 'iː'; last_v = 'I'; i = j; continue
            if c == 'ة':
                # ta marbuta en pausa
                v = 'a'
                if T and T[-1].endswith('a'): pass
                else: T.append('a'); I.append('a')
                i = j; last_v = 'a'; continue
            if c in 'أإؤئء' and (not T or T[-1].endswith('-')):
                t, p = '', 'ʔ'
            dbl = SHADDA in marks
            v = ''
            if FATHA in marks: v = 'a'
            elif KASRA in marks: v = 'i'
            elif DAMMA in marks: v = 'u'
            tan = next((TAN[x] for x in marks if x in TAN), '')
            if DAGGER in marks: v = 'ā'
            if sun_skip[0]:
                sun_skip[0] = False; unit_t = t + v + tan
                unit_p = p + 'ː' + v.replace('ā', 'aː') + tan
                T.append(unit_t); I.append(unit_p)
                last_v = 'tan' if tan else (v if v in 'aiu' and v else ('A' if v == 'ā' else ''))
                i = j; continue
            unit_t = (t * 2 if dbl and t else t) + v + tan
            unit_p = (p + 'ː' if dbl else p) + (v.replace('ā', 'aː')) + tan
            T.append(unit_t); I.append(unit_p)
            last_v = 'tan' if tan else (v if v in 'aiu' and v else ('A' if v == 'ā' else ''))
            i = j; continue
        i += 1
    tr = ''.join(T)
    tr = tr.replace('ʾʾ', 'ʾ')
    return tr, ''.join(I)

MARKS = '\u064b\u064c\u064d\u064e\u064f\u0650\u0651\u0652\u0670'

def _conv(text, k, pausal=True):
    ws = re.findall(r'[\u0600-\u06ff\u0750-\u077f]+', text)
    out = []
    for n, w in enumerate(ws):
        last = n == len(ws) - 1
        if pausal and w and w[-1] in '\u064e\u064f\u0650\u064c\u064d':
            w = w[:-1]  # forma de pausa: sense vocal final de cas
        r = _word(w)[k]
        if pausal and r.endswith('iyy'): r = r[:-3] + 'ī'
        if pausal and r.endswith('ijː'): r = r[:-3] + 'iː'
        # tāʾ marbūṭa seguida d'un complement (iḍāfa): -at
        if not last and w.rstrip(MARKS).endswith('\u0629') and r.endswith('a'):
            r += 't'
        out.append(r)
    return out

def translit(text, pausal=True):
    return ' / '.join(' '.join(_conv(p, 0, pausal)) for p in text.split('/'))

def ipa(text, pausal=True):
    parts = [' '.join(_conv(p, 1, pausal)) for p in text.split('/')]
    parts = [p for p in parts if p]
    return '[' + ' / '.join(parts) + ']' if parts else ''

if __name__ == '__main__':
    for w in ['كِتَاب', 'كُتُب', 'مَدْرَسَة', 'بَيْت', 'يَوْم', 'الشَّمْس', 'القَمَر', 'شُكْرًا', 'سَيَّارَة', 'مُعَلِّم', 'كَبِير', 'صَغِير', 'طَالِب',
              'أَب', 'إِخْوَة', 'سُؤَال', 'مَاء', 'مُسْتَشْفَى', 'قَهْوَة', 'يَكْتُبُ', 'اِسْتَقْبَلَ', 'قُرْآن', 'فِي', 'هُوَ', 'لَيْلَة', 'جَمِيل', 'مَسَاءُ الْخَيْرِ']:
        print(w, translit(w), ipa(w))
