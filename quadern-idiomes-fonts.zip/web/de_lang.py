"""Alemany: formes verbals regulars, comparatius i IPA aproximada."""
import re

INSEP = ('be', 'ge', 'er', 'ver', 'zer', 'ent', 'emp', 'miss', 'über', 'unter', 'wider', 'hinter')

def _stem(inf):
    if inf.endswith('eln') or inf.endswith('ern'): return inf[:-1]
    if inf.endswith('en'): return inf[:-2]
    if inf.endswith('n'): return inf[:-1]
    return inf

def _needs_e(stem):
    return bool(re.search(r'(t|d|chn|ffn|gn|dm|tm)$', stem))

def weak_forms(word, sein=False):
    """Formes d'un verb dèbil: (3a sg present, Präteritum 3a sg, Perfekt)."""
    refl = word.startswith('sich ')
    w = word[5:] if refl else word
    obj = ''
    if ' ' in w:
        obj, w = w.rsplit(' ', 1)
    pre = ''
    if '·' in w:
        pre, w = w.split('·', 1)
    st = _stem(w)
    e = 'e' if _needs_e(st) else ''
    pres = st + e + 't'
    prat = st + e + 'te'
    if w.endswith('ieren') or w.startswith(INSEP):
        pii = st + e + 't'
    else:
        pii = 'ge' + st + e + 't'
    aux = 'ist' if sein else 'hat'
    if refl:
        pres += ' sich'; prat += ' sich'; aux += ' sich'
    if obj:
        pres += ' ' + obj; prat += ' ' + obj; aux += ' ' + obj
    if pre:
        pres = pres + ' ' + pre
        prat = prat + ' ' + pre
        pii = pre + pii
    return pres, prat, f'{aux} {pii}'

def comparative(adj, umlaut=False):
    a = adj
    if umlaut:
        a = re.sub(r'([aou])([^aeiouäöü]*)$', lambda m: {'a': 'ä', 'o': 'ö', 'u': 'ü'}[m.group(1)] + m.group(2), a, count=1)
        a = re.sub(r'au([^aeiou]*)$', r'äu\1', adj) if 'au' in adj and umlaut and a == adj else a
    comp = (a[:-1] if a.endswith('e') else a) + 'er'
    if a.endswith('el'): comp = a[:-2] + 'ler'
    if a.endswith('er') and not a.endswith('eer'): comp = a[:-2] + 'rer'
    sup_e = 'e' if re.search(r'(d|t|s|ß|x|z|sch|tz)$', a) and not a.endswith('isch') else ''
    sup = 'am ' + a + sup_e + 'sten' if not a.endswith('e') else 'am ' + a + 'sten'
    if adj == 'groß': sup = 'am größten'
    return comp, sup

# ---------------------------------------------------------------- IPA aproximada
LONG_SHORT = {'a': ('aː', 'a'), 'e': ('eː', 'ɛ'), 'i': ('iː', 'ɪ'), 'o': ('oː', 'ɔ'), 'u': ('uː', 'ʊ'),
              'ä': ('ɛː', 'ɛ'), 'ö': ('øː', 'œ'), 'ü': ('yː', 'ʏ'), 'y': ('yː', 'ʏ')}
SHORT_WORDS = {'mit', 'an', 'in', 'im', 'um', 'es', 'das', 'was', 'ob', 'ab', 'bis', 'hat', 'man', 'weg', 'von', 'und', 'des', 'drin', 'ich', 'bin',
               'ist', 'den', 'dem', 'wenn', 'denn', 'dann', 'zum', 'vom', 'am', 'uns', 'unten', 'oft', 'not', 'fast', 'ganz', 'als', 'hin', 'her'}
VOW = 'aeiouäöüy'
UNSTRESSED_PREF = ('be', 'ge', 'er', 'ver', 'zer', 'ent', 'emp')
STRESS_SUFFIX = [('ieren', 1), ('ei', 0), ('ion', 0), ('jon', 0), ('tät', 0), ('ist', 0), ('ent', 0), ('ant', 0), ('ur', 0), ('ie', 0)]
NOPREF = {'geben', 'gegen', 'gehen', 'gestern', 'besser', 'beste', 'besten', 'beten', 'erde', 'erste', 'ernst', 'ende', 'gelb', 'gerne', 'geld', 'ernte', 'beere', 'besen', 'gebet'}

def _segments(w):
    """Divideix en grafemes."""
    G = ['tsch', 'sch', 'chs', 'ch', 'ck', 'ph', 'th', 'tz', 'ng', 'nk', 'qu', 'pf', 'ie', 'ei', 'ai', 'ey', 'eu', 'äu', 'au', 'aa', 'ee', 'oo', 'ss', 'ß']
    out = []; i = 0
    while i < len(w):
        for g in G:
            if w.startswith(g, i):
                if g == 'ie' and i + 2 < len(w) + 1 and w[i + 2:i + 3] == 'n' and i + 3 == len(w) and False: pass
                out.append(g); i += len(g); break
        else:
            out.append(w[i]); i += 1
    return out

def de_word_ipa(word):
    w = word.lower()
    w = re.sub(r'[^a-zäöüß]', '', w)
    if not w: return ''
    w = w.replace('tion', 'zjon')
    seg = _segments(w)
    # síl·labes: índexs de nuclis vocàlics
    nuclei = [k for k, g in enumerate(seg) if g[0] in VOW]
    if not nuclei: return w
    # accent
    stress = 0
    for p in UNSTRESSED_PREF:
        if w.startswith(p) and len(nuclei) > 1 and len(w) > len(p) + 2 and w[len(p)] not in VOW + 'h' and w not in NOPREF:
            stress = 1; break
    for suf, extra in STRESS_SUFFIX:
        if w.endswith(suf) and len(nuclei) > 1:
            if suf == 'ie' and not re.search(r'(gie|rie|tie|phie|mie|nie)$', w): continue
            if suf == 'ur' and not w.endswith(('tur', 'atur', 'ur')): continue
            if suf in ('ist', 'ent', 'ant') and len(nuclei) < 2: continue
            stress = len(nuclei) - 1 - extra; break
    out = []
    sidx = None
    n = len(seg)
    for k, g in enumerate(seg):
        if not g: continue
        nxt = seg[k + 1] if k + 1 < n else ''
        nxt2 = seg[k + 2] if k + 2 < n else ''
        prev = seg[k - 1] if k > 0 else ''
        last = (k == n - 1)
        if g[0] in VOW:
            vi = nuclei.index(k); st = (vi == stress)
            if g in ('ie',): v = 'iː' if st or not last else 'iː'
            elif g in ('ei', 'ai', 'ey'): v = 'aɪ̯'
            elif g in ('eu', 'äu'): v = 'ɔʏ̯'
            elif g == 'au': v = 'aʊ̯'
            elif g in ('aa', 'ee', 'oo'): v = LONG_SHORT[g[0]][0]
            else:
                L, S = LONG_SHORT[g]
                cons_after = 0; j = k + 1
                while j < n and seg[j][0] not in VOW:
                    cons_after += 2 if seg[j] in ('ss', 'ck', 'tz', 'sch', 'ng', 'pf', 'chs') else (1 if seg[j] != 'h' else 0); j += 1
                if nxt == 'h' and (k + 2 >= n or seg[k + 2][0] not in VOW): v = L
                elif g == 'e' and not st:
                    v = 'ə'
                    if nxt == 'r' and (k + 2 == n or (k + 3 == n and nxt2 == 'n')): v = 'ɐ'; out.append(v); seg[k + 1] = ''; continue
                elif not st and len(nuclei) > 1: v = S if cons_after >= 2 else L.replace('ː', '')
                elif cons_after >= 2: v = S
                elif cons_after == 1 and j >= n:
                    v = S if w in SHORT_WORDS else L
                elif cons_after == 0 and j >= n: v = L
                else: v = L
            if g == 'i' and nxt == 'g' and k + 2 == n: v = 'ɪ'
            if st and len(nuclei) > 1: sidx = len(out)
            out.append(v)
            continue
        if g == '': continue
        if g == 'h':
            if prev and prev[0] in VOW: continue
            out.append('h'); continue
        if g == 'r':
            if prev and prev[0] in VOW and (not nxt or nxt[0] not in VOW): out.append('ɐ̯')
            else: out.append('ʁ')
            continue
        if g in ('ch',):
            if k == 0: out.append('k' if nxt[:1] in ('r', 'o', 'a', 'l') else 'ç')
            elif prev in ('a', 'o', 'u', 'au'): out.append('x')
            else: out.append('ç')
            continue
        if g == 'g' and last and prev == 'i': out.append('ç'); continue
        if g == 's':
            if (k == 0 or (prev and prev[0] in 'lmnr' + VOW)) and nxt and nxt[0] in VOW: out.append('z'); continue
            if (k == 0) and nxt in ('p', 't'): out.append('ʃ'); continue
            out.append('s'); continue
        m = {'sch': 'ʃ', 'tsch': 'tʃ', 'chs': 'ks', 'ck': 'k', 'ph': 'f', 'th': 't', 'tz': 'ts', 'z': 'ts', 'ng': 'ŋ', 'nk': 'ŋk', 'qu': 'kv',
             'pf': 'pf', 'ss': 's', 'ß': 's', 'v': 'f', 'w': 'v', 'j': 'j', 'x': 'ks', 'c': 'k'}
        c = m.get(g, g)
        # ensordiment final
        if c in ('b', 'd', 'g') and (last or (nxt and nxt[0] not in VOW and nxt not in ('l', 'r'))):
            c = {'b': 'p', 'd': 't', 'g': 'k'}[c]
        out.append(c)
    if sidx is not None:
        j = sidx
        CL = {'ʃt', 'ʃp', 'ʃv', 'ʃl', 'ʃm', 'ʃn', 'tʁ', 'pʁ', 'bʁ', 'kʁ', 'ɡʁ', 'gʁ', 'fʁ', 'dʁ', 'ʃʁ', 'pl', 'bl', 'kl', 'gl', 'fl', 'kv', 'tsv', 'tsj'}
        if j > 0 and out[j - 1] and out[j - 1][-1] not in 'aeiouɛɪɔʊøœyʏəɐː̯':
            j -= 1
            if j > 0 and (out[j - 1] + out[j]) in CL: j -= 1
        if all(not o or o[-1] not in 'aeiouɛɪɔʊøœyʏəɐː̯' for o in out[:j]) : j = 0
        out.insert(j, 'ˈ')
    s = ''.join(out)
    s = re.sub(r'([bdfɡklmnpstvzʃ])\1', r'\1', s)
    s = s.replace('g', 'ɡ')
    return s

def ipa(text):
    t = re.sub(r'\(.*?\)', '', text).replace('·', '')
    ws = [x for x in re.split(r'[\s>/,]+', t) if x and x not in ('der', 'die', 'das', 'sich', 'am', '-')]
    ws = [x for x in ws if re.search('[a-zA-ZäöüÄÖÜß]', x)]
    return '[' + ' '.join(de_word_ipa(x) for x in ws) + ']' if ws else ''

if __name__ == '__main__':
    for v in ['machen', 'arbeiten', 'wandern', 'studieren', 'besuchen', 'ein·kaufen', 'sich freuen', 'reisen', 'an·melden', 'sich kennen·lernen']:
        print(v, weak_forms(v, v == 'reisen'))
    for a, u in [('klein', 0), ('alt', 1), ('kurz', 1), ('dunkel', 1 * 0), ('teuer', 0), ('heiß', 0), ('müde', 0), ('groß', 1), ('nett', 0)]:
        print(a, comparative(a, bool(u)))
    for w in ['Tisch', 'Mann', 'Frau', 'Kinder', 'Mädchen', 'Straße', 'Bahnhof', 'Zeitung', 'studieren', 'Bäckerei', 'Information', 'Universität', 'Wasser',
              'Sprache', 'besuchen', 'Vater', 'Zug', 'heute', 'schön', 'Stadt', 'spielen', 'Brot', 'gehen', 'lesen', 'Abend', 'wichtig', 'Hand']:
        print(w, ipa(w))
