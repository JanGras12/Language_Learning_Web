"""Construeix site/data/ko.json a partir de /home/claude/langs/ko/*.txt i ko_gram*.txt."""
import json, re, glob, os
from collections import OrderedDict
from ko_lang import romanize, ipa, haeyo

D = '/home/claude/langs/ko/'
LV = ['A1', 'A2', 'B1', 'B2']

def lvlist():
    m = {}
    for line in open(D + 'levels_n01_08.txt'):
        k, v = line.split(':', 1); m[k.strip()] = ' ' + v.strip() + ' '
    return m
LVL = lvlist()
def guess_level(w):
    for k in ('A1', 'A2'):
        if ' ' + w + ' ' in LVL[k]: return k
    return 'B1'

def junk(f):
    return all(x.strip() in ('—', '', '-') for x in f[1:])

def read(prefix, nf, default_lv=None):
    secs = OrderedDict(); bad = []
    for path in sorted(glob.glob(D + prefix + '*.txt')):
        sec = None; lv = default_lv
        for line in open(path, encoding='utf8'):
            line = line.rstrip('\n')
            if not line.strip() or line.startswith('levels'): continue
            if line.startswith('@'): lv = line[1:].strip(); continue
            if line.startswith('#'):
                sec = line[1:].strip(); secs.setdefault(sec, []); continue
            f = [x.strip() for x in line.split('|')]
            if len(f) != nf: bad.append((path, line)); continue
            if junk(f) or any(x in ('—', '') for x in f): continue
            secs[sec].append({'f': f, 'lv': lv})
    return secs, bad

def main():
    nouns, b1 = read('n', 4)
    verbs, b2 = read('v', 4)
    adjs, b3 = read('a', 4)
    advs, b4 = read('d', 4)
    conns, b5 = read('c', 5)
    for b in (b1, b2, b3, b4, b5):
        for x in b: print('BAD', x)
    # nivell per defecte dels noms antics
    for s, rows in nouns.items():
        for r in rows:
            if r['lv'] is None: r['lv'] = guess_level(r['f'][0])
    # verbs: treure claudàtors manuals
    for secs in (verbs, adjs):
        for rows in secs.values():
            for r in rows: r['f'][1] = re.sub(r'\s*\[nom [^\]]*\]', '', r['f'][1])
    stats = {}
    def dedupe(secs, keyf=lambda r: r['f'][0].split('*')[0]):
        seen = {}; out = OrderedDict()
        for s, rows in secs.items():
            keep = []
            for r in rows:
                k = keyf(r)
                if k in seen:
                    o = seen[k]
                    have = [x.strip() for x in o['f'][1].split(';')]
                    for x in r['f'][1].split(';'):
                        if x.strip() and x.strip() not in have: have.append(x.strip())
                    o['f'][1] = '; '.join(have)
                    if LV.index(r['lv']) < LV.index(o['lv']): o['lv'] = r['lv']
                    stats['merged'] = stats.get('merged', 0) + 1
                    continue
                seen[k] = r; keep.append(r)
            out[s] = keep
        return out, seen
    nouns, nk = dedupe(nouns); verbs, vk = dedupe(verbs); adjs, ak = dedupe(adjs); advs, dk = dedupe(advs)
    conns, ck = dedupe(conns, lambda r: r['f'][1])
    # verbs que també són adjectius: es queden a adjectius
    for s in verbs: verbs[s] = [r for r in verbs[s] if r['f'][0].split('*')[0] not in ak]
    # noms vs adverbis: el nom guanya, excepte aquests
    ADV_WINS = {'미리'}
    for s in nouns: nouns[s] = [r for r in nouns[s] if r['f'][0] not in ADV_WINS]
    nk = {r['f'][0] for rows in nouns.values() for r in rows}
    for s in advs: advs[s] = [r for r in advs[s] if r['f'][0] not in nk]
    # 하다: el nom s'absorbeix en el verb/adjectiu
    absorbed = 0
    nounmap = {r['f'][0]: r for rows in nouns.values() for r in rows}
    for secs in (verbs, adjs):
        for rows in secs.values():
            for r in rows:
                w = r['f'][0].split('*')[0]
                if w.endswith('하다') and len(w) > 2 and w[:-2] in nounmap:
                    n = nounmap.pop(w[:-2])
                    r['f'][1] += f"  [nom {w[:-2]}: {n['f'][1]}]"
                    if LV.index(n['lv']) < LV.index(r['lv']): r['lv'] = n['lv']
                    absorbed += 1
    keepn = set(nounmap)
    for s in nouns: nouns[s] = [r for r in nouns[s] if r['f'][0] in keepn]
    # ------- construir fulls
    def vocab(sid, title, cols, secs, rowf):
        rows = []
        for s, rr in secs.items():
            if not rr: continue
            rows.append({'s': s})
            for r in rr:
                c, ip = rowf(r['f'])
                rows.append({'c': c, 'ipa': ip, 'lv': r['lv']})
        return {'id': sid, 'kind': 'vocab', 't': title, 'cols': cols, 'rows': rows}
    C = lambda h, role: {'h': h, 'role': role}
    def nrow(f):
        ko, ca, ex, trx = f
        return [ca, ko, romanize(ko), ex, trx], ipa(ko)
    def vrow(f):
        w, ca, ex, trx = f
        irr = None
        if '*' in w: w, irr = w.split('*')
        h, typ = haeyo(w, irr)
        return [ca, w, h, typ, romanize(w), ex, trx], ipa(w)
    def drow(f):
        ko, ca, ex, trx = f
        return [ca, ko, romanize(ko), ex, trx], ipa(ko)
    def crow(f):
        ca, ko, tip, ex, trx = f
        if '-' in ko or re.search('[\u3131-\u318e]', ko):
            return [ca, ko, '', tip, ex, trx], ''
        clean = re.sub(r'[()/]', ' ', ko)
        return [ca, ko, romanize(clean).strip(), tip, ex, trx], ipa(clean)
    S = []
    S.append(vocab('nouns', {'ca': 'Noms', 'en': 'Nouns'},
                   [C('Català', 'tr'), C('Coreà', 'tl'), C('Romanització', 'pr'), C('Frase (KO)', 'ex'), C('Frase (CA)', 'trx')], nouns, nrow))
    vc = [C('Català', 'tr'), C('Coreà', 'tl'), C('Forma -아요/어요', 'tl2'), C('Tipus', 'x'), C('Romanització', 'pr'), C('Frase (KO)', 'ex'), C('Frase (CA)', 'trx')]
    S.append(vocab('verbs', {'ca': 'Verbs', 'en': 'Verbs'}, vc, verbs, vrow))
    S.append(vocab('adjectives', {'ca': 'Adjectius', 'en': 'Adjectives'}, vc, adjs, vrow))
    S.append(vocab('adverbs', {'ca': 'Adverbis', 'en': 'Adverbs'},
                   [C('Català', 'tr'), C('Coreà', 'tl'), C('Romanització', 'pr'), C('Frase (KO)', 'ex'), C('Frase (CA)', 'trx')], advs, drow))
    S.append(vocab('connectors', {'ca': 'Connectors', 'en': 'Connectors'},
                   [C('Català', 'tr'), C('Connector', 'tl'), C('Romanització', 'pr'), C('Tipus', 'x'), C('Frase (KO)', 'ex'), C('Frase (CA)', 'trx')], conns, crow))
    # ------- gramàtica
    G = OrderedDict()
    for path in ('ko_gram1.txt', 'ko_gram2.txt'):
        cur = None
        for line in open(path, encoding='utf8'):
            line = line.rstrip('\n')
            if not line.strip(): continue
            if line.startswith('==='):
                sid, ca, en = [x.strip() for x in line[3:].split('|')]
                cur = {'id': sid, 'kind': 'grammar', 't': {'ca': ca, 'en': en}, 'items': []}; G[sid] = cur; continue
            p = line.split('|')
            if p[0] == 'T': cur['items'].append(['T', p[2], p[1]])
            elif p[0] == 'P': cur['items'].append(['P', '|'.join(p[1:])])
            elif p[0] in ('H', 'R'): cur['items'].append([p[0], p[1:]])
    counts = {s['id']: sum(1 for r in s['rows'] if 'c' in r) for s in S}
    bylv = {s['id']: {l: sum(1 for r in s['rows'] if r.get('lv') == l) for l in LV[:3]} for s in S}
    guide = [['G', "Coreà A1–B1: quadern d'estudi"],
             ['T', 'Contingut'],
             ['K', 'Recompte', f"Noms: {counts['nouns']}  ·  Verbs: {counts['verbs']}  ·  Adjectius: {counts['adjectives']}  ·  Adverbis: {counts['adverbs']}  ·  Connectors: {counts['connectors']}", ''],
             ['K', 'Per nivell', '  ·  '.join(f"{ {'nouns': 'Noms', 'verbs': 'Verbs', 'adjectives': 'Adjectius'}[k]}: " + ' / '.join(f"{l} {v}" for l, v in bylv[k].items()) for k in ('nouns', 'verbs', 'adjectives')), 'Fes servir el selector de nivells (A1, A2, B1) de dalt per veure només el que vols estudiar.'],
             ['K', 'Com està organitzat', "Cada fila: traducció al català, paraula en hangul, romanització, frase en coreà i traducció. Els temes són files blaves. Els oposats van seguits. Verbs i adjectius porten la forma cortesa -아요/어요 (la més útil per parlar) i el tipus de conjugació (regular, 하다, irregulars).", ''],
             ['K', 'Sense repeticions', f"Cap paraula no es repeteix. Les paraules homògrafes (말: paraula / cavall; 배: panxa / vaixell / pera) surten en una sola fila amb tots els sentits. Els {absorbed} noms que formen verb amb 하다 (공부 → 공부하다) no surten a Noms: el seu significat apareix entre claudàtors al verb.", ''],
             ['T', 'Pestanyes'],
             ['K', 'Hangul', "Com funciona l'alfabet: consonants, vocals, blocs sil·làbics, batchim, regles de pronunciació i romanització.", ''],
             ['K', 'Noms · Verbs · Adjectius · Adverbis · Connectors', 'Vocabulari per temes amb nivell A1, A2 o B1.', ''],
             ['K', 'Conjugació', 'Arrel, -아요/어요, formes bàsiques, passat, futur, irregulars, formes B1, passiu i causatiu.', ''],
             ['K', 'Partícules', 'Partícules de cas (은/는, 이/가, 을/를, 에, 에서…), d\'èmfasi i de final de frase.', ''],
             ['K', 'Adjectius i adverbis', "Conjugació dels adjectius, forma davant del nom, comparació, adverbis i adverbis que demanen negació.", ''],
             ['K', 'Posposicions i lloc', "Noms de posició (위, 아래, 앞…), on / cap a on / d'on, temps i règim verbal.", ''],
             ['K', 'Nivells de cortesia', 'Formal, cortès, informal, honorífics i humilitat.', ''],
             ['K', 'Números i comptadors', 'Números natius i sinocoreans, quan s\'usa cada sèrie i comptadors.', ''],
             ['K', 'Oracions', "Ordre SOV, subordinades (causa, condició, temps, finalitat, concessió), relatives, estil indirecte.", ''],
             ['T', 'Llegeix això abans de fiar-te del material'],
             ['K', 'Selecció i nivells', "He triat jo les paraules a partir del meu coneixement, sense cap llista de freqüència verificada. Els nivells A1/A2/B1 són una estimació meva inspirada en el TOPIK I (nivells 1–2 ≈ A1–A2) i el TOPIK II nivell 3 (≈ B1); no hi ha cap llista oficial pública que jo hagi pogut consultar.", ''],
             ['K', 'Romanització i IPA', "Les genera un programa a partir del hangul aplicant les regles de pronunciació (enllaç, nasalització, assimilació de ㄹ, tensió, aspiració, palatalització). No tracta la inserció de ㄴ (십육 [심뉵]) ni algunes excepcions lèxiques. La forma -아요/어요 també es genera per regla a partir del tipus marcat a mà.", ''],
             ['K', 'Traduccions i frases', "Escrites per mi, no revisades per un parlant nadiu. Si una frase et sembla estranya, comprova-la (Naver Dictionary, 국립국어원 표준국어대사전).", ''],
             ['K', 'Dades que poden haver canviat', "Res d'aquest material depèn de dades en temps real.", '']]
    sheets = [{'id': 'guide', 'kind': 'guide', 't': {'ca': 'Guia', 'en': 'Guide'}, 'items': guide}, G['alphabet']] + S + \
             [G['conjugation'], G['cases'], G['adjadv'], G['prepositions'], G['politeness'], G['numbers'], G['sentences']]
    out = {'id': 'ko', 'name': {'ca': 'Coreà', 'en': 'Korean'}, 'native': '한국어', 'levels': 'A1–B1', 'lvset': ['A1', 'A2', 'B1'], 'sheets': sheets}
    json.dump(out, open('site/data/ko.json', 'w'), ensure_ascii=False, separators=(',', ':'))
    print(counts, bylv, 'absorbed', absorbed, stats, os.path.getsize('site/data/ko.json') // 1024, 'KB')

if __name__ == '__main__':
    main()
