"""Xinès: segmentació del pinyin i IPA aproximada amb lletres de to."""
import re, unicodedata

TONED = {}
for base, marks in {'a': 'āáǎà', 'e': 'ēéěè', 'i': 'īíǐì', 'o': 'ōóǒò', 'u': 'ūúǔù', 'ü': 'ǖǘǚǜ'}.items():
    for t, ch in enumerate(marks, 1):
        TONED[ch] = (base, t)
INITIALS = ['zh', 'ch', 'sh', 'b', 'p', 'm', 'f', 'd', 't', 'n', 'l', 'g', 'k', 'h', 'j', 'q', 'x', 'r', 'z', 'c', 's', 'y', 'w']
FINALS = ['iang', 'iong', 'uang', 'ueng', 'ang', 'eng', 'ing', 'ong', 'ian', 'iao', 'uai', 'uan', 'üan', 'ai', 'ei', 'ao', 'ou', 'an', 'en', 'in',
          'un', 'ün', 'ia', 'ie', 'iu', 'ua', 'uo', 'ui', 'üe', 'ue', 'er', 'a', 'o', 'e', 'i', 'u', 'ü', 'ê']
FIPA = {'a': 'a', 'o': 'wo', 'e': 'ɤ', 'ai': 'ai', 'ei': 'ei', 'ao': 'ɑu', 'ou': 'ou', 'an': 'an', 'en': 'ən', 'ang': 'ɑŋ', 'eng': 'əŋ',
        'ong': 'ʊŋ', 'er': 'aɚ', 'i': 'i', 'ia': 'ja', 'ie': 'jɛ', 'iao': 'jɑu', 'iou': 'jou', 'ian': 'jɛn', 'in': 'in', 'iang': 'jɑŋ',
        'ing': 'iŋ', 'iong': 'jʊŋ', 'u': 'u', 'ua': 'wa', 'uo': 'wo', 'uai': 'wai', 'uei': 'wei', 'uan': 'wan', 'uen': 'wən', 'uang': 'wɑŋ',
        'ueng': 'wəŋ', 'ü': 'y', 'üe': 'ɥɛ', 'üan': 'ɥɛn', 'ün': 'yn', 'ê': 'ɛ'}
IIPA = {'b': 'p', 'p': 'pʰ', 'm': 'm', 'f': 'f', 'd': 't', 't': 'tʰ', 'n': 'n', 'l': 'l', 'g': 'k', 'k': 'kʰ', 'h': 'x', 'j': 'tɕ', 'q': 'tɕʰ',
        'x': 'ɕ', 'zh': 'ʈʂ', 'ch': 'ʈʂʰ', 'sh': 'ʂ', 'r': 'ɻ', 'z': 'ts', 'c': 'tsʰ', 's': 's', '': ''}
TONE = {1: '˥', 2: '˧˥', 3: '˨˩˦', 4: '˥˩', 5: ''}

def norm(word):
    """Retorna (lletres sense to, llista de posicions amb to)."""
    out, tones = '', {}
    for ch in unicodedata.normalize('NFC', word.lower()):
        if ch in TONED:
            b, t = TONED[ch]; tones[len(out)] = t; out += b
        elif ch == 'v': out += 'ü'
        else: out += ch
    return out, tones

def valid(s, first):
    ini = next((i for i in INITIALS if s.startswith(i)), '')
    fin = s[len(ini):]
    if not fin: return False
    if not ini and not first: return False  # síl·laba vocàlica interna requereix apòstrof
    return fin in FINALS

def split_word(w):
    s, tones = norm(w)
    s = s.replace("'", '|').replace('’', '|')
    parts = []
    pos = 0
    for chunk in s.split('|'):
        n = len(chunk); best = [None] * (n + 1); best[0] = []
        for i in range(n):
            if best[i] is None: continue
            for L in range(6, 0, -1):
                if i + L <= n and valid(chunk[i:i + L], i == 0):
                    if best[i + L] is None: best[i + L] = best[i] + [(i, i + L)]
        # erhua -r final
        segs = best[n]
        er = False
        if segs is None and chunk.endswith('r') and best[n - 1] is not None:
            segs = best[n - 1]; er = True
        if segs is None: return None
        for a, b in segs:
            t = next((tones[pos + k] for k in range(a, b) if pos + k in tones), 5)
            parts.append([chunk[a:b], t, False])
        if er: parts[-1][2] = True
        pos += len(chunk) + 1
    return parts

def syl_ipa(s, t, er):
    ini = next((i for i in INITIALS if s.startswith(i)), '')
    fin = s[len(ini):]
    if ini == 'y':
        ini = ''
        fin = {'i': 'i', 'a': 'ia', 'e': 'ie', 'ao': 'iao', 'ou': 'iou', 'an': 'ian', 'in': 'in', 'ang': 'iang', 'ing': 'ing', 'ong': 'iong',
               'u': 'ü', 'ue': 'üe', 'uan': 'üan', 'un': 'ün', 'o': 'io'}.get(fin, 'i' + fin)
    elif ini == 'w':
        ini = ''
        fin = {'u': 'u', 'a': 'ua', 'o': 'uo', 'ai': 'uai', 'ei': 'uei', 'an': 'uan', 'en': 'uen', 'ang': 'uang', 'eng': 'ueng'}.get(fin, 'u' + fin)
    if ini in ('j', 'q', 'x') and fin.startswith('u'): fin = 'ü' + fin[1:]
    if fin == 'ue': fin = 'üe'
    fin = {'ui': 'uei', 'iu': 'iou', 'un': 'uen'}.get(fin, fin)
    if fin == 'i' and ini in ('z', 'c', 's'): f = 'ɹ̩'
    elif fin == 'i' and ini in ('zh', 'ch', 'sh', 'r'): f = 'ɻ̩'
    elif fin == 'o' and ini in ('b', 'p', 'm', 'f'): f = 'wo'
    elif fin == 'io': f = 'jo'
    else: f = FIPA.get(fin, fin)
    if er: f += '˞'
    return IIPA[ini] + f + TONE[t]

def ipa(pinyin):
    words = [w for w in re.split(r"[\s…\-,/()·.]+", pinyin) if w and re.search('[a-zA-Zāáǎàēéěèīíǐìōóǒòūúǔùǖǘǚǜü]', w)]
    out = []
    for w in words:
        sp = split_word(w)
        if sp is None: return ''
        out.append('.'.join(syl_ipa(*p) for p in sp))
    return '[' + ' '.join(out) + ']' if out else ''

if __name__ == '__main__':
    for p in ['nǐ hǎo', 'Zhōngguó', 'dàngāo', "nǚ'ér", 'xiānsheng', 'yìdiǎnr', 'shì', 'zìxíngchē', 'qùnián', 'xuéxiào', 'yuǎn', 'wǒmen', 'jiějie',
              'piányi', 'chuānghu', 'liúxuéshēng', 'tiān', 'nǚrén', 'kě\'ài', 'xióngmāo', 'shénme', 'cídiǎn', 'èr', 'zhuàn', 'lǜsè', 'suīrán … dànshì']:
        print(p, ipa(p))
