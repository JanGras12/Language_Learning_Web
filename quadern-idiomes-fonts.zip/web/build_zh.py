"""Construeix site/data/zh.json a partir de /home/claude/langs/zh/*.txt i zh_gram*.txt."""
import json, re, glob, os
from collections import OrderedDict, Counter
from zh_lang import ipa

D = '/home/claude/langs/zh/'
LV = ['A1', 'A2', 'B1']
MWP = {'个': 'gè', '位': 'wèi', '口': 'kǒu', '本': 'běn', '张': 'zhāng', '只': 'zhī', '条': 'tiáo', '件': 'jiàn', '双': 'shuāng', '杯': 'bēi',
       '瓶': 'píng', '碗': 'wǎn', '块': 'kuài', '把': 'bǎ', '辆': 'liàng', '台': 'tái', '家': 'jiā', '座': 'zuò', '棵': 'kē', '朵': 'duǒ',
       '支': 'zhī', '首': 'shǒu', '部': 'bù', '封': 'fēng', '篇': 'piān', '节': 'jié', '次': 'cì', '顿': 'dùn', '套': 'tào', '种': 'zhǒng',
       '所': 'suǒ', '扇': 'shàn', '盏': 'zhǎn', '面': 'miàn', '间': 'jiān', '颗': 'kē', '根': 'gēn', '片': 'piàn', '场': 'chǎng', '道': 'dào',
       '斤': 'jīn', '串': 'chuàn', '头': 'tóu', '匹': 'pǐ', '架': 'jià', '列': 'liè', '趟': 'tàng', '幅': 'fú', '项': 'xiàng', '份': 'fèn',
       '副': 'fù', '顶': 'dǐng', '枚': 'méi', '卷': 'juǎn', '床': 'chuáng', '口 (olla)': 'kǒu', '名': 'míng', '起': 'qǐ', '段': 'duàn',
       '门': 'mén', '笔': 'bǐ', '阵': 'zhèn', '滴': 'dī', '群': 'qún', '支 (equip)': 'zhī'}
NUMERALS = set('一 二 两 三 四 五 六 七 八 九 十 百 千 万 零 亿 半'.split())

def read(prefix, nf):
    secs = OrderedDict(); bad = []
    for path in sorted(glob.glob(D + prefix + '*.txt')):
        sec = None; lv = None
        for line in open(path, encoding='utf8'):
            line = line.rstrip('\n')
            if not line.strip(): continue
            if line.startswith('@'): lv = line[1:].strip(); continue
            if line.startswith('#'): sec = line[1:].strip(); secs.setdefault(sec, []); continue
            f = [x.strip() for x in line.split('|')]
            if len(f) != nf: bad.append((path, line)); continue
            if any(x in ('—', '') for i, x in enumerate(f) if not (prefix == 'n' and i == 2)): continue
            secs[sec].append({'f': f, 'lv': lv})
    for b in bad: print('BAD', b)
    return secs

def main():
    nouns = read('n', 6); verbs = read('v', 5); adjs = read('a', 5); advs = read('d', 5); conns = read('c', 6)
    # els números purs van a la pestanya «Números i classificadors»
    for s in nouns: nouns[s] = [r for r in nouns[s] if r['f'][0] not in NUMERALS]
    stats = Counter()
    def merge_meaning(dst, src_txt, tag=''):
        have = [x.strip() for x in re.split(r';', dst)]
        add = [x.strip() for x in src_txt.split(';') if x.strip() and x.strip() not in have]
        if not add: return dst
        return dst + (f'  [{tag}: ' + '; '.join(add) + ']' if tag else '; ' + '; '.join(add))
    def dedupe(secs, ci):
        seen = {}; out = OrderedDict()
        for s, rows in secs.items():
            keep = []
            for r in rows:
                k = r['f'][0]
                if k in seen:
                    o = seen[k]; o['f'][ci] = merge_meaning(o['f'][ci], r['f'][ci])
                    if LV.index(r['lv']) < LV.index(o['lv']): o['lv'] = r['lv']
                    stats['dup'] += 1; continue
                seen[k] = r; keep.append(r)
            out[s] = keep
        return out, seen
    nouns, nk = dedupe(nouns, 3); verbs, vk = dedupe(verbs, 2); adjs, ak = dedupe(adjs, 2); advs, dk = dedupe(advs, 2)
    conns, ck = dedupe(conns, 0)
    # paraules en dues categories: es queden en una sola fila amb l'altre sentit entre claudàtors
    def absorb(dst_map, ci_dst, src_secs, ci_src, tag):
        for s in src_secs:
            keep = []
            for r in src_secs[s]:
                k = r['f'][0]
                if k in dst_map:
                    d = dst_map[k]; d['f'][ci_dst] = merge_meaning(d['f'][ci_dst], r['f'][ci_src], tag)
                    if LV.index(r['lv']) < LV.index(d['lv']): d['lv'] = r['lv']
                    stats['absorbed'] += 1
                else: keep.append(r)
            src_secs[s] = keep
    absorb(vk, 2, adjs, 2, 'adj.'); ak = {r['f'][0]: r for rows in adjs.values() for r in rows}
    absorb(vk, 2, nouns, 3, 'nom'); absorb(ak, 2, nouns, 3, 'nom')
    absorb(vk, 2, advs, 2, 'adv.'); absorb(ak, 2, advs, 2, 'adv.')
    nk = {r['f'][0]: r for rows in nouns.values() for r in rows}
    absorb(nk, 3, advs, 2, 'adv.')
    dk = {r['f'][0] for rows in advs.values() for r in rows}
    for s in conns: conns[s] = [r for r in conns[s] if r['f'][1] not in dk]
    C = lambda h, role: {'h': h, 'role': role}
    def vocab(sid, title, cols, secs, rowf):
        rows = []
        for s, rr in secs.items():
            if not rr: continue
            rows.append({'s': s})
            for r in rr:
                c, ip = rowf(r['f'])
                rows.append({'c': c, 'ipa': ip, 'lv': r['lv']})
        return {'id': sid, 'kind': 'vocab', 't': title, 'cols': cols, 'rows': rows}
    def nrow(f):
        h, p, mw, ca, ex, trx = f
        mwc = '—' if mw in ('—', '') else f"{mw} {MWP.get(mw, '')}".strip()
        return [ca, h, p, mwc, ex, trx], ipa(p)
    def wrow(f):
        h, p, ca, ex, trx = f
        return [ca, h, p, ex, trx], ipa(p)
    def crow(f):
        ca, h, p, tip, ex, trx = f
        return [ca, h, p, tip, ex, trx], ipa(p)
    S = []
    S.append(vocab('nouns', {'ca': 'Noms', 'en': 'Nouns'}, [C('Català', 'tr'), C('Hanzi', 'tl'), C('Pinyin', 'pr'), C('Classificador', 'x'), C('Frase (ZH)', 'ex'), C('Frase (CA)', 'trx')], nouns, nrow))
    wc = [C('Català', 'tr'), C('Hanzi', 'tl'), C('Pinyin', 'pr'), C('Frase (ZH)', 'ex'), C('Frase (CA)', 'trx')]
    S.append(vocab('verbs', {'ca': 'Verbs', 'en': 'Verbs'}, wc, verbs, wrow))
    S.append(vocab('adjectives', {'ca': 'Adjectius', 'en': 'Adjectives'}, wc, adjs, wrow))
    S.append(vocab('adverbs', {'ca': 'Adverbis', 'en': 'Adverbs'}, wc, advs, wrow))
    S.append(vocab('connectors', {'ca': 'Connectors', 'en': 'Connectors'}, [C('Català', 'tr'), C('Connector', 'tl'), C('Pinyin', 'pr'), C('Tipus', 'x'), C('Frase (ZH)', 'ex'), C('Frase (CA)', 'trx')], conns, crow))
    noipa = sum(1 for s in S for r in s['rows'] if 'c' in r and not r['ipa'])
    G = OrderedDict()
    for path in ('zh_gram1.txt', 'zh_gram2.txt'):
        cur = None
        for line in open(path, encoding='utf8'):
            line = line.rstrip('\n')
            if not line.strip(): continue
            if line.startswith('==='):
                sid, ca, en = [x.strip() for x in line[3:].split('|')]
                cur = {'id': sid, 'kind': 'grammar', 't': {'ca': ca, 'en': en}, 'items': []}; G[sid] = cur; continue
            p = line.split('|')
            if p[0] == 'T': cur['items'].append(['T', p[2], p[1]])
            elif p[0] == 'P': cur['items'].append(['P', '|'.join(p[1:])])
            elif p[0] in ('H', 'R'): cur['items'].append([p[0], p[1:]])
    counts = {s['id']: sum(1 for r in s['rows'] if 'c' in r) for s in S}
    bylv = {s['id']: Counter(r['lv'] for r in s['rows'] if 'c' in r) for s in S}
    nm = {'nouns': 'Noms', 'verbs': 'Verbs', 'adjectives': 'Adjectius'}
    total = sum(counts.values())
    guide = [['G', "Xinès A1–B1: quadern d'estudi"],
             ['T', 'Contingut'],
             ['K', 'Recompte', f"Noms: {counts['nouns']}  ·  Verbs: {counts['verbs']}  ·  Adjectius: {counts['adjectives']}  ·  Adverbis: {counts['adverbs']}  ·  Connectors: {counts['connectors']}  ·  Total: {total}", ''],
             ['K', 'Per nivell', '  ·  '.join(nm[k] + ': ' + ' / '.join(f"{l} {bylv[k][l]}" for l in LV) for k in nm), 'Fes servir el selector de nivells de dalt per veure només el que vols estudiar.'],
             ['K', 'Com està organitzat', "Cada fila: traducció al català, caràcters (simplificats), pinyin amb tons, frase en xinès i traducció. Els noms porten el seu classificador. Els temes són files blaves; els oposats van seguits.", ''],
             ['K', 'Sense repeticions', f"Moltes paraules xineses són alhora verb i nom (工作 «treballar / feina») o adjectiu i adverbi (特别). Surten en una sola fila, a la categoria principal, amb l'altre sentit entre claudàtors. Els números purs (一, 二, 三…) són a la pestanya Números i classificadors.", ''],
             ['T', 'Pestanyes'],
             ['K', 'Pinyin i tons', "El xinès no té alfabet: aquesta pestanya explica el pinyin, els quatre tons, els canvis de to, inicials i finals, i com estan fets els caràcters (radicals).", ''],
             ['K', 'Verbs: temps i aspecte', 'Els verbs no es conjuguen: 了, 过, 着, 在, negació amb 不 i 没, verbs modals, complements de resultat, direccionals, potencials i de grau.', ''],
             ['K', 'Partícules', '的, 吗, 呢, 吧, 了, 过, 着, 得, 地; preguntes i interrogatius.', ''],
             ['K', 'Adjectius i adverbis', 'Adjectius com a predicat, comparació amb 比, reduplicació i posició dels adverbis.', ''],
             ['K', 'Coverbs i lloc', 'Les «preposicions» xineses (在, 从, 到, 给, 跟, 对…), paraules de posició, 在 / 有 / 是, i 把 i 被.', ''],
             ['K', 'Números i classificadors', 'Números, classificadors (量词) amb exemples, dates, hores i diners.', ''],
             ['K', 'Oracions', "Ordre de la frase, relatives amb 的, 是…的, comparatives i subordinades fins a B1.", ''],
             ['T', 'Llegeix això abans de fiar-te del material'],
             ['K', 'Volum', f"El quadern té {total} paraules. Com a referència, l'HSK 3.0 (2021) demana 2.245 paraules acumulades fins al nivell 3 i 3.245 fins al nivell 4 (dades de Wikipedia; l'equivalència HSK–MECR no és oficial). Aquest material cobreix el nucli A1–B1, però no totes les paraules de la llista HSK.", ''],
             ['K', 'Selecció i nivells', "He triat jo les paraules i n'he estimat el nivell (HSK 1–2 ≈ A1, HSK 3 ≈ A2, HSK 4 ≈ B1) sense consultar la llista oficial paraula per paraula.", ''],
             ['K', 'Pinyin', "Escrit per mi amb el to de diccionari (sense aplicar els canvis de to de 不 i 一, excepte en expressions fixes). Les frases d'exemple NO porten pinyin: no tenia cap diccionari en aquest entorn per generar-lo sense errors amb els caràcters de diverses lectures (了, 得, 行, 长…).", ''],
             ['K', 'IPA', "Generada per programa a partir del pinyin, amb lletres de to (˥ ˧˥ ˨˩˦ ˥˩). Transcripció aproximada de la paraula aïllada, sense canvis de to.", ''],
             ['K', 'Traduccions i frases', "Escrites per mi, no revisades per un parlant nadiu. Comprova els dubtes en un diccionari (Pleco, MDBG).", ''],
             ['K', 'Dades que poden haver canviat', "Res d'aquest material depèn de dades en temps real.", '']]
    sheets = [{'id': 'guide', 'kind': 'guide', 't': {'ca': 'Guia', 'en': 'Guide'}, 'items': guide}, G['alphabet']] + S + \
             [G['conjugation'], G['cases'], G['adjadv'], G['prepositions'], G['numbers'], G['sentences']]
    out = {'id': 'zh', 'name': {'ca': 'Xinès', 'en': 'Chinese'}, 'native': '中文', 'levels': 'A1–B1', 'lvset': LV, 'sheets': sheets}
    json.dump(out, open('site/data/zh.json', 'w'), ensure_ascii=False, separators=(',', ':'))
    print(counts, {k: dict(v) for k, v in bylv.items()}, dict(stats), 'noIPA', noipa, os.path.getsize('site/data/zh.json') // 1024, 'KB')

if __name__ == '__main__':
    main()
