"""Construeix site/data/de.json a partir de /home/claude/langs/de/*.txt i de_gram*.txt."""
import json, re, glob, os
from collections import OrderedDict, Counter
from de_lang import weak_forms, comparative, ipa

D = '/home/claude/langs/de/'
LV = ['A1', 'A2', 'B1']

def read(prefix, nf):
    secs = OrderedDict(); bad = []
    for path in sorted(glob.glob(D + prefix + '*.txt')):
        sec = None; lv = None
        for line in open(path, encoding='utf8'):
            line = line.rstrip('\n')
            if not line.strip(): continue
            if line.startswith('@'): lv = line[1:].strip(); continue
            if line.startswith('#'): sec = line[1:].strip(); secs.setdefault(sec, []); continue
            f = [x.strip() for x in line.split('|')]
            if len(f) != nf: bad.append((path, line)); continue
            if any(x in ('—', '') for i, x in enumerate(f) if not (prefix == 'n' and i == 1)): continue
            if '(' in f[0] and prefix in ('n', 'v', 'a', 'd'): continue  # notes internes
            secs[sec].append({'f': f, 'lv': lv})
    for b in bad: print('BAD', b[0][-7:], b[1][:60])
    return secs

def key(word):
    w = word.split('>')[0].split('*')[0].split('@')[0].replace('·', '')
    w = re.sub(r'^(der|die|das|sich) ', '', w)
    return w.lower()

def main():
    nouns = read('n', 5); verbs = read('v', 4); adjs = read('a', 4); advs = read('d', 4); conns = read('c', 5)
    stats = Counter()
    def dedupe(secs, kf, ci):
        seen = {}; out = OrderedDict()
        for s, rows in secs.items():
            keep = []
            for r in rows:
                k = kf(r)
                if k in seen:
                    o = seen[k]
                    have = [x.strip() for x in o['f'][ci].split(';')]
                    for x in r['f'][ci].split(';'):
                        if x.strip() and x.strip() not in have: have.append(x.strip())
                    o['f'][ci] = '; '.join(have); stats['dup'] += 1; continue
                seen[k] = r; keep.append(r)
            out[s] = keep
        return out, seen
    nouns, nk = dedupe(nouns, lambda r: r['f'][0].lower(), 2)
    verbs, vk = dedupe(verbs, lambda r: key(r['f'][0]), 1)
    adjs, ak = dedupe(adjs, lambda r: key(r['f'][0]), 1)
    advs, dk = dedupe(advs, lambda r: r['f'][0].lower(), 1)
    conns, ck = dedupe(conns, lambda r: r['f'][1].lower(), 0)
    # adverbis que també són adjectius: es queden a adjectius
    for s in advs:
        advs[s] = [r for r in advs[s] if r['f'][0].lower() not in ak]
    C = lambda h, role: {'h': h, 'role': role}
    def vocab(sid, title, cols, secs, rowf):
        rows = []
        for s, rr in secs.items():
            if not rr: continue
            rows.append({'s': s})
            for r in rr:
                c, ip = rowf(r['f'])
                rows.append({'c': c, 'ipa': ip, 'lv': r['lv']})
        return {'id': sid, 'kind': 'vocab', 't': title, 'cols': cols, 'rows': rows}
    GEN = {'der': 'm', 'die': 'f', 'das': 'n'}
    def nrow(f):
        w, pl, ca, ex, trx = f
        art = w.split(' ')[0]
        g = GEN.get(art, '—')
        if w in ('die Eltern', 'die Leute', 'die Geschwister', 'die Großeltern', 'die Möbel', 'die Ferien', 'die Nachrichten', 'die Nebenkosten', 'die USA'): g = 'pl'
        plural = '—' if pl in ('—', '') else ('die ' + pl)
        return [ca, w, g, plural, ex, trx], ipa(w)
    def vrow(f):
        w, ca, ex, trx = f
        if '>' in w:
            inf, pres, prat, pii = [x.strip() for x in w.split('>')]
        else:
            sein = w.endswith('@s'); inf = w[:-2] if sein else w
            pres, prat, pii = weak_forms(inf, sein)
        disp = inf.replace('·', '')
        return [ca, disp, pres, prat, pii, ex, trx], ipa(disp)
    def arow(f):
        w, ca, ex, trx = f
        if '>' in w:
            pos, comp, sup = [x.strip() for x in w.split('>')]
        else:
            um = w.endswith('*U'); pos = w[:-2] if um else w
            if pos.endswith('-') or pos in ('super', 'lila', 'rosa', 'orange', 'tot', 'leer') and False:
                comp, sup = '—', '—'
            else:
                comp, sup = comparative(pos, um)
            if pos.endswith('-') or pos in ('lila', 'rosa', 'orange', 'super', 'schwanger', 'tot', 'kaputt', 'fertig', 'geschlossen', 'ledig', 'verheiratet', 'geschieden', 'deutsch', 'spanisch', 'katalanisch', 'europäisch', 'international', 'öffentlich', 'privat', 'kostenlos', 'leer', 'voll', 'offen', 'besetzt', 'frei', 'gesamt', 'einzig', 'perfekt', 'falsch', 'richtig', 'bereit', 'erlaubt', 'verboten', 'gültig', 'zentral', 'politisch', 'wirtschaftlich', 'sozial', 'offiziell', 'typisch', 'ausländisch', 'ländlich', 'städtisch', 'traditionell', 'modern', 'aktuell', 'täglich', 'unmöglich', 'möglich', 'ganz', 'genug'):
                comp, sup = '—', '—'
        return [ca, pos, comp, sup, ex, trx], ipa(pos.rstrip('-'))
    def drow(f):
        w, ca, ex, trx = f
        return [ca, w, ex, trx], ipa(w)
    def crow(f):
        ca, w, tip, ex, trx = f
        return [ca, w, tip, ex, trx], ipa(re.sub(r'[…/()]', ' ', w))
    S = []
    S.append(vocab('nouns', {'ca': 'Noms', 'en': 'Nouns'}, [C('Català', 'tr'), C('Alemany', 'tl'), C('Gènere', 'x'), C('Plural', 'tl2'), C('Frase (DE)', 'ex'), C('Frase (CA)', 'trx')], nouns, nrow))
    S.append(vocab('verbs', {'ca': 'Verbs', 'en': 'Verbs'}, [C('Català', 'tr'), C('Infinitiu', 'tl'), C('Present (er)', 'tl2'), C('Pretèrit (er)', 'x'), C('Perfekt', 'x'), C('Frase (DE)', 'ex'), C('Frase (CA)', 'trx')], verbs, vrow))
    S.append(vocab('adjectives', {'ca': 'Adjectius', 'en': 'Adjectives'}, [C('Català', 'tr'), C('Alemany', 'tl'), C('Comparatiu', 'tl2'), C('Superlatiu', 'x'), C('Frase (DE)', 'ex'), C('Frase (CA)', 'trx')], adjs, arow))
    S.append(vocab('adverbs', {'ca': 'Adverbis', 'en': 'Adverbs'}, [C('Català', 'tr'), C('Alemany', 'tl'), C('Frase (DE)', 'ex'), C('Frase (CA)', 'trx')], advs, drow))
    S.append(vocab('connectors', {'ca': 'Connectors', 'en': 'Connectors'}, [C('Català', 'tr'), C('Connector', 'tl'), C('Tipus / ordre', 'x'), C('Frase (DE)', 'ex'), C('Frase (CA)', 'trx')], conns, crow))
    G = OrderedDict()
    for path in ('de_gram1.txt', 'de_gram2.txt'):
        cur = None
        for line in open(path, encoding='utf8'):
            line = line.rstrip('\n')
            if not line.strip(): continue
            if line.startswith('==='):
                sid, ca, en = [x.strip() for x in line[3:].split('|')]
                cur = {'id': sid, 'kind': 'grammar', 't': {'ca': ca, 'en': en}, 'items': []}; G[sid] = cur; continue
            p = line.split('|')
            if p[0] == 'T': cur['items'].append(['T', p[2], p[1]])
            elif p[0] == 'P': cur['items'].append(['P', '|'.join(p[1:])])
            elif p[0] in ('H', 'R'): cur['items'].append([p[0], p[1:]])
    counts = {s['id']: sum(1 for r in s['rows'] if 'c' in r) for s in S}
    bylv = {s['id']: Counter(r['lv'] for r in s['rows'] if 'c' in r) for s in S}
    total = sum(counts.values())
    nm = {'nouns': 'Noms', 'verbs': 'Verbs', 'adjectives': 'Adjectius'}
    guide = [['G', "Alemany A1–B1: quadern d'estudi"],
             ['T', 'Contingut'],
             ['K', 'Recompte', f"Noms: {counts['nouns']}  ·  Verbs: {counts['verbs']}  ·  Adjectius: {counts['adjectives']}  ·  Adverbis: {counts['adverbs']}  ·  Connectors: {counts['connectors']}  ·  Total: {total}", ''],
             ['K', 'Per nivell', '  ·  '.join(nm[k] + ': ' + ' / '.join(f"{l} {bylv[k][l]}" for l in LV) for k in nm), 'Fes servir el selector de nivells de dalt per veure només el que vols estudiar.'],
             ['K', 'Com està organitzat', "Noms amb article (der/die/das), gènere i plural. Verbs amb 3a persona del present, pretèrit i Perfekt (amb haben o sein). Adjectius amb comparatiu i superlatiu. Els temes són files blaves; els oposats van seguits.", ''],
             ['T', 'Pestanyes'],
             ['K', 'Alfabet i pronunciació', 'Les lletres, ä ö ü ß, combinacions (sch, ch, ei, ie, eu…), vocals llargues i curtes, accent i ensordiment final.', ''],
             ['K', 'Conjugació', 'Present, sein/haben/werden, canvis de vocal, modals, separables, Perfekt, Präteritum, imperatiu, futur, reflexius, Konjunktiv II, passiva i verbs amb preposició.', ''],
             ['K', 'Casos i declinació', 'Els quatre casos, articles, kein, pronoms, possessius, gènere, plural, n-Deklination i genitiu.', ''],
             ['K', 'Adjectius i adverbis', 'Declinació de l\'adjectiu (dèbil, mixta, forta), comparació i ordre dels adverbis.', ''],
             ['K', 'Preposicions', 'Preposicions amb acusatiu, datiu, doble cas i genitiu; on / cap a on / d\'on; temps.', ''],
             ['K', 'Números', 'Números, ordinals, dates, preus i l\'hora.', ''],
             ['K', 'Oracions', 'Verb en 2a posició, pinça verbal, subordinades amb verb al final, relatives, um…zu, condicional.', ''],
             ['T', 'Llegeix això abans de fiar-te del material'],
             ['K', 'Selecció i nivells', f"El quadern té {total} paraules triades per mi. Els nivells són una estimació meva inspirada en les llistes de vocabulari dels exàmens Goethe (Start Deutsch 1, Goethe-Zertifikat A2 i B1), que no he consultat entrada per entrada.", ''],
             ['K', 'Formes verbals', "Les formes dels verbs irregulars les he escrites a mà; les dels verbs regulars (dèbils) i els comparatius regulars les genera un programa. Comprova els casos dubtosos en un diccionari (Duden, DWDS).", ''],
             ['K', 'IPA', "Generada per programa amb regles (vocals llargues i curtes, accent, ensordiment final, -er, ch). És aproximada: falla en préstecs i en algunes paraules compostes.", ''],
             ['K', 'Traduccions i frases', "Escrites per mi, no revisades per un parlant nadiu.", ''],
             ['K', 'Dades que poden haver canviat', "Res d'aquest material depèn de dades en temps real.", '']]
    sheets = [{'id': 'guide', 'kind': 'guide', 't': {'ca': 'Guia', 'en': 'Guide'}, 'items': guide}, G['alphabet']] + S + \
             [G['conjugation'], G['cases'], G['adjadv'], G['prepositions'], G['numbers'], G['sentences']]
    out = {'id': 'de', 'name': {'ca': 'Alemany', 'en': 'German'}, 'native': 'Deutsch', 'levels': 'A1–B1', 'lvset': LV, 'sheets': sheets}
    json.dump(out, open('site/data/de.json', 'w'), ensure_ascii=False, separators=(',', ':'))
    print(counts, total, {k: dict(v) for k, v in bylv.items()}, dict(stats), os.path.getsize('site/data/de.json') // 1024, 'KB')

if __name__ == '__main__':
    main()
