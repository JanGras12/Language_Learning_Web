"""Genera site/data/stats.json: paraules per categoria i nivell per a cada idioma."""
import json, glob, os
order = ['ja', 'ru', 'ko', 'zh', 'de', 'ar']
out = []
for code in order:
    p = f'site/data/{code}.json'
    if not os.path.exists(p): continue
    d = json.load(open(p))
    lvs = d.get('lvset', ['A1', 'A2', 'B1'])
    rows = []
    for s in d['sheets']:
        if s['kind'] != 'vocab': continue
        c = {l: 0 for l in lvs}
        for r in s['rows']:
            if 'c' in r: c[r.get('lv', lvs[-1])] = c.get(r.get('lv', lvs[-1]), 0) + 1
        rows.append({'id': s['id'], 't': s['t'], 'c': c, 'n': sum(c.values())})
    gram = {l: 0 for l in lvs}
    for s in d['sheets']:
        if s['kind'] == 'grammar':
            for it in s['items']:
                if it[0] == 'T' and len(it) > 2 and it[2] in gram: gram[it[2]] += 1
    out.append({'id': code, 'name': d['name'], 'native': d['native'], 'levels': d['levels'], 'lvset': lvs, 'rows': rows, 'gram': gram})
json.dump(out, open('site/data/stats.json', 'w'), ensure_ascii=False)
for o in out: print(o['id'], sum(r['n'] for r in o['rows']))
