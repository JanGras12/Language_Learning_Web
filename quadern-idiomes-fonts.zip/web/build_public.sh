#!/bin/sh
# Genera la versió autònoma (GitHub Pages, Netlify…) a /home/claude/web/public
set -e
cd /home/claude/web
rm -rf public && mkdir -p public/data
{ printf '<!doctype html>\n<html lang="ca">\n<head>\n<meta charset="utf-8">\n<meta name="viewport" content="width=device-width, initial-scale=1">\n<meta name="description" content="Quadern d%sestudi d%sidiomes A1–B2: japonès, rus, coreà, xinès, alemany i àrab, amb gramàtica, vocabulari per nivells, transliteració i IPA.">\n' "'" "'"; sed '/<meta name="claude:viewport-fit-sides"/d' site/index.html; printf '\n</html>\n'; } > public/index.html
for f in site/data/*.json; do b=$(basename $f); [ "$b" = index.json ] || cp $f public/data/; done
touch public/.nojekyll
cp PUBLIC_README.md public/README.md
echo "fet: $(du -sh public | cut -f1)"
