"""Construeix data/ja.json i data/ru.json (amb l'ampliació del rus i la IPA)."""
import json, re, unicodedata, os
from ipa import ru_ipa, ru_resp, ru_text_ipa_from_resp, ACC

def strip_acc(s):
    return unicodedata.normalize('NFC', unicodedata.normalize('NFD', s).replace(ACC, ''))

def plain_key(s):
    return re.sub(r'\s*\(.*?\)', '', strip_acc(s)).strip().lower()

def read(path, nf):
    secs = []
    for line in open(path, encoding='utf8'):
        line = line.rstrip('\n')
        if not line.strip(): continue
        if line.startswith('#'):
            secs.append((line[1:].strip(), [])); continue
        f = [x.strip() for x in line.split('|')]
        assert len(f) == nf, (path, line)
        secs[-1][1].append(f)
    return secs

def adj_end(m):
    w = strip_acc(m)
    if w.endswith('ой'):
        return '-ая, -ое, -ие' if w[-3] in 'гкхжшщч' else '-ая, -ое, -ые'
    if w.endswith('ий'):
        if w[-3] in 'гкх': return '-ая, -ое, -ие'
        if w[-3] in 'жшщч': return '-ая, -ее, -ие'
        return '-яя, -ее, -ие'
    return '-ая, -ое, -ые'

def insert(sheet, secs, rowfn):
    """Afegeix files: a la secció existent amb el mateix nom (al final), o en una secció nova al final."""
    rows = sheet['rows']
    existing = {}
    for i, r in enumerate(rows):
        if 's' in r: existing[r['s']] = i
    keys = {plain_key(r['c'][1]) + '|' + (plain_key(r['c'][2]) if sheet['id'] == 'verbs' else '') for r in rows if 'c' in r}
    added = dupl = 0
    for name, items in secs:
        new = []
        for f in items:
            row = rowfn(f)
            k = plain_key(row['c'][1]) + '|' + (plain_key(row['c'][2]) if sheet['id'] == 'verbs' else '')
            if k in keys:
                dupl += 1; print('  DUP', sheet['id'], row['c'][1]); continue
            keys.add(k); new.append(row); added += 1
        if name in existing:
            i = existing[name] + 1
            while i < len(rows) and 'c' in rows[i]: i += 1
            rows[i:i] = new
            existing = {r['s']: j for j, r in enumerate(rows) if 's' in r}
        else:
            rows.append({'s': name}); rows.extend(new)
    print(sheet['id'], '+', added, 'dup', dupl)

def verb_row(f):
    cat, imp, pf, ex, trx = f
    resp = ru_resp(imp) + (' / ' + ru_resp(pf) if pf != '—' else '')
    ipa = ru_ipa(imp) + (' / ' + ru_ipa(pf) if pf != '—' else '')
    return {'c': [cat, strip_acc(imp), strip_acc(pf), resp, strip_acc(ex), trx], 'ipa': ipa, 'new': 1}

def adj_row(f):
    cat, m, ex, trx = f
    return {'c': [cat, strip_acc(m), adj_end(m), ru_resp(m), strip_acc(ex), trx], 'ipa': ru_ipa(m), 'new': 1}

def conn_row(f):
    cat, w, tip, ex, trx = f
    w2 = w.replace('...', ' ').replace(' / ', ' ')
    return {'c': [cat, strip_acc(w), ru_resp(w2), tip, strip_acc(ex), trx], 'ipa': ru_ipa(w2), 'new': 1}

def sheet(S, sid):
    return next(s for s in S if s['id'] == sid)

def count(s):
    return sum(1 for r in s['rows'] if 'c' in r)

EN_TITLES = {'guide': 'Guide', 'alphabet': 'Alphabet', 'nouns': 'Nouns', 'verbs': 'Verbs', 'adjectives': 'Adjectives',
             'adverbs': 'Adverbs', 'connectors': 'Connectors', 'conjugation': 'Conjugation', 'cases': 'Cases',
             'adjadv': 'Adjectives & adverbs', 'prepositions': 'Prepositions', 'sentences': 'Sentences'}

def main():
    ja = json.load(open('raw_ja.json')); ru = json.load(open('raw_ru.json'))
    # --- correcció puntual: кровать sense síl·laba tònica marcada
    for r in sheet(ru, 'nouns')['rows']:
        if r.get('c', [None, None])[1] == 'кровать':
            r['c'][3] = "kra-VÁT'"; r['ipa'] = ru_text_ipa_from_resp('кровать', "kra-VÁT'")
    # --- ampliació del rus
    insert(sheet(ru, 'verbs'), read('ru_new_verbs.txt', 5), verb_row)
    insert(sheet(ru, 'adjectives'), read('ru_new_adj.txt', 4), adj_row)
    insert(sheet(ru, 'connectors'), read('ru_new_conn.txt', 5), conn_row)
    # --- Guia: recomptes actualitzats + notes de la web
    def patch_guide(S, counts_txt, extra):
        g = sheet(S, 'guide')['items']
        for it in g:
            if it[0] == 'K' and it[1] == 'Recompte': it[2] = counts_txt
        # inserir notes abans de "Dades que poden haver canviat"
        idx = next(i for i, it in enumerate(g) if it[0] == 'K' and it[1].startswith('Dades que poden'))
        g[idx:idx] = extra
    rc = {k: count(sheet(ru, k)) for k in ('nouns', 'verbs', 'adjectives', 'adverbs', 'connectors')}
    patch_guide(ru, f"Noms: {rc['nouns']}  ·  Verbs: {rc['verbs']} (parelles imperfectiu + perfectiu)  ·  Adjectius: {rc['adjectives']}  ·  Adverbis: {rc['adverbs']}  ·  Connectors: {rc['connectors']}", [
        ['K', 'Ampliació A1–B1', f"Respecte a l'Excel original s'hi han afegit {rc['verbs']-212} parelles de verbs, {rc['adjectives']-289} adjectius i {rc['connectors']-35} connectors (marcats amb «nou»). La pronunciació d'aquestes files la genera el mateix programa de regles a partir de l'accent que he marcat jo.", ''],
        ['K', 'IPA', "La columna IPA (opcional) es genera automàticament a partir de l'accent de cada paraula: reducció vocàlica (ɐ, ə, ɪ), palatalització (ʲ) i assimilació de sonoritat. És una transcripció aproximada de la paraula aïllada; no reflecteix l'entonació de la frase. Comprova els casos dubtosos a Wiktionary.", '']])
    jc = {k: count(sheet(ja, k)) for k in ('nouns', 'verbs', 'adjectives', 'adverbs', 'connectors')}
    patch_guide(ja, f"Kana: 114 files  ·  Noms: {jc['nouns']}  ·  Verbs: {jc['verbs']}  ·  Adjectius: {jc['adjectives']}  ·  Adverbis: {jc['adverbs']}  ·  Connectors: {jc['connectors']}", [
        ['K', 'IPA', "La columna IPA (opcional) es genera automàticament a partir del kana: vocals llargues (ː), consonants dobles, ん assimilada (m, n, ŋ, ɲ, ɴ). No marca l'accent tonal ni l'ensordiment de i/u entre consonants sordes (です ≈ [des]). És una aproximació.", '']])
    meta = {
        'ja': {'id': 'ja', 'name': {'ca': 'Japonès', 'en': 'Japanese'}, 'native': '日本語', 'levels': 'A1–B2', 'font': 'jp'},
        'ru': {'id': 'ru', 'name': {'ca': 'Rus', 'en': 'Russian'}, 'native': 'Русский', 'levels': 'A1–B1', 'font': 'cyr'},
    }
    os.makedirs('site/data', exist_ok=True)
    for code, S in (('ja', ja), ('ru', ru)):
        for s in S:
            s['t'] = {'ca': s.get('title', 'Guia'), 'en': EN_TITLES[s['id']]}
            s.pop('title', None)
        if code == 'ja': sheet(S, 'cases')['t'] = {'ca': 'Partícules', 'en': 'Particles'}; sheet(S, 'alphabet')['t'] = {'ca': 'Kana', 'en': 'Kana'}
        if code == 'ru': sheet(S, 'cases')['t'] = {'ca': 'Casos', 'en': 'Cases'}
        out = dict(meta[code], sheets=S)
        json.dump(out, open(f'site/data/{code}.json', 'w'), ensure_ascii=False, separators=(',', ':'))
        print(code, os.path.getsize(f'site/data/{code}.json') // 1024, 'KB')
    json.dump([dict(m, sheets=None) for m in meta.values()], open('site/data/index.json', 'w'), ensure_ascii=False)

if __name__ == '__main__':
    main()
