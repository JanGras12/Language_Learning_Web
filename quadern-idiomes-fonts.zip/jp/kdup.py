import glob,collections
d=collections.defaultdict(list)
for f in sorted(glob.glob('data/[nvad][0-9]*.txt')):
    for i,l in enumerate(open(f),1):
        if l.startswith('#') or not l.strip(): continue
        p=l.split('|')
        if p[1] not in ('—',p[0]): d[p[1]].append((p[0],f.split('/')[-1],i))
for k,v in d.items():
    if len(v)>1: print(k,v)
