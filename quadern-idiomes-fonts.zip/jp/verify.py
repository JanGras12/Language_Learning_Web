import openpyxl,re,collections,sys
wb=openpyxl.load_workbook(sys.argv[1])
KANA=re.compile(r'^[぀-ヿー〜・ 　/]+$')
issues=collections.Counter(); seen={}; out=[]
cols={'Noms':(2,3,5),'Verbs':(2,3,7),'Adjectius':(2,3,6),'Adverbis':(2,3,5),'Connectors':(2,3,6)}
for sh,(ck,cj,cf) in cols.items():
    ws=wb[sh]
    for r in range(2,ws.max_row+1):
        k=ws.cell(r,ck).value; j=ws.cell(r,cj).value; f=ws.cell(r,cf).value
        if k is None: continue
        if not KANA.match(k): out.append(('KANA',sh,r,k,j)); issues['kana']+=1
        key=(k,j)
        if key in seen: out.append(('DUP',sh,r,k,j,seen[key])); issues['dup']+=1
        seen[key]=(sh,r)
        if not ws.cell(r,4).value: out.append(('ROMAJI',sh,r,k)); issues['romaji']+=1
        jj=(j or '').strip('()')
        cands=[]
        if jj and jj!='—':
            cands.append(jj)
            # stem: drop trailing kana
            st=re.sub(r'[぀-ゟ]+$','',jj)
            if st: cands.append(st)
        kk=k.replace('〜','')
        cands.append(kk)
        if sh=='Verbs':
            cands.append(kk[:-1]); 
            if kk.endswith('する'): cands.append(kk[:-2])
        if sh=='Adjectius' and kk.endswith('い'): cands.append(kk[:-1])
        if f and not any(c and c in f for c in cands):
            out.append(('NOTIN',sh,r,k,j,f)); issues['notin']+=1
print(dict(issues))
for o in out: print(o)
