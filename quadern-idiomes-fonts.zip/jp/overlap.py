import glob
def rows(p):
    out=[]
    for f in sorted(glob.glob(p)):
        for i,l in enumerate(open(f),1):
            if l.startswith('#') or not l.strip(): continue
            out.append((f,i,l.rstrip('\n').split('|')))
    return out
N=rows('data/n*.txt'); V=rows('data/v*.txt'); A=rows('data/a*.txt'); D=rows('data/d*.txt')
vk={(r[2][0],r[2][1]) for r in V}
hits=[]
for f,i,r in N:
    k,kj=r[0],r[1]
    if (k+'する', (kj+'する') if kj!='—' else '—') in vk: hits.append((f,i,k,kj))
print(len(hits)); print(' '.join(h[3] for h in hits))
