#!/bin/bash
# remove junk rows (translation field '—')
for f in data/[nvadc][0-9]*.txt; do awk -F'|' '!(NF>=3 && $3=="—")' "$f" > "$f.tmp" && mv "$f.tmp" "$f"; done
python3 check.py
