import glob,re,sys,collections
NF={'n':5,'v':7,'a':6,'d':5,'c':6}
seen={};tot=collections.Counter();bad=0
files=sorted(glob.glob('data/[vadc][0-9]*.txt'))+sorted(glob.glob('data/n[0-9]*.txt'))
nov=0
for f in files:
    k=f.split('/')[-1][0]
    for i,l in enumerate(open(f),1):
        l=l.rstrip('\n')
        if not l or l.startswith('#'): continue
        p=l.split('|')
        if len(p)!=NF[k]: print('FIELDS',f,i,l); bad+=1; continue
        kana,kanji=p[0],p[1]
        if kanji==kana: kanji='—'
        key=(kana,kanji if kanji!='—' else '')
        if key in seen:
            if k=='n' and not seen[key].startswith('data/n'): nov+=1
            else: print('DUP',f,i,kana,kanji,'<->',seen[key])
        else: seen[key]=f'{f}:{i}'
        if kanji==kana: kanji='—'
        if re.search(r'[a-zA-Z]',kana): print('LATIN',f,i,l)
        tot[k]+=1
print(dict(tot),'bad',bad,'noun-overlaps(removed at build)',nov)
