# -*- coding: utf-8 -*-
import glob, re, math, collections, sys
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.worksheet.datavalidation import DataValidation
from openpyxl.utils import get_column_letter
import gram_verbs, gram_particles, gram_adj, gram_post, gram_sent

OUT = sys.argv[1] if len(sys.argv) > 1 else 'Japones_A1-B2.xlsx'

# ---------------- romaji (wāpuro, fidel a la grafia kana) ----------------
K = {}
base = {
 'ア':'a','イ':'i','ウ':'u','エ':'e','オ':'o','カ':'ka','キ':'ki','ク':'ku','ケ':'ke','コ':'ko',
 'サ':'sa','シ':'shi','ス':'su','セ':'se','ソ':'so','タ':'ta','チ':'chi','ツ':'tsu','テ':'te','ト':'to',
 'ナ':'na','ニ':'ni','ヌ':'nu','ネ':'ne','ノ':'no','ハ':'ha','ヒ':'hi','フ':'fu','ヘ':'he','ホ':'ho',
 'マ':'ma','ミ':'mi','ム':'mu','メ':'me','モ':'mo','ヤ':'ya','ユ':'yu','ヨ':'yo',
 'ラ':'ra','リ':'ri','ル':'ru','レ':'re','ロ':'ro','ワ':'wa','ヲ':'o','ン':'n',
 'ガ':'ga','ギ':'gi','グ':'gu','ゲ':'ge','ゴ':'go','ザ':'za','ジ':'ji','ズ':'zu','ゼ':'ze','ゾ':'zo',
 'ダ':'da','ヂ':'ji','ヅ':'zu','デ':'de','ド':'do','バ':'ba','ビ':'bi','ブ':'bu','ベ':'be','ボ':'bo',
 'パ':'pa','ピ':'pi','プ':'pu','ペ':'pe','ポ':'po','ヴ':'vu',
 'ァ':'a','ィ':'i','ゥ':'u','ェ':'e','ォ':'o'}
yoon = {'ャ':'a','ュ':'u','ョ':'o'}
special = {'ティ':'ti','ディ':'di','トゥ':'tu','ドゥ':'du','ファ':'fa','フィ':'fi','フェ':'fe','フォ':'fo',
 'ウィ':'wi','ウェ':'we','ウォ':'wo','シェ':'she','ジェ':'je','チェ':'che','ヴァ':'va','ヴィ':'vi','ヴェ':'ve','ヴォ':'vo',
 'デュ':'dyu','テュ':'tyu','フュ':'fyu','イェ':'ye','クァ':'kwa','グァ':'gwa','ツァ':'tsa'}
def hira2kata(s):
    return ''.join(chr(ord(c)+0x60) if 'ぁ' <= c <= 'ゖ' else c for c in s)
def romaji(s):
    if s.endswith('する') and len(s) > 2 and not s.startswith('〜'):
        return romaji(s[:-2]) + ' suru'
    s = hira2kata(s.replace('〜','').replace('～',''))
    out = []; i = 0; dbl = False
    while i < len(s):
        c = s[i]; n = s[i+1] if i+1 < len(s) else ''
        syl = None
        if c+n in special: syl = special[c+n]; i += 2
        elif n in yoon and c in base and c not in 'ャュョ':
            b = base[c]
            if b in ('shi','chi','ji'): syl = b[:-1] + yoon[n]
            else: syl = b[:-1] + 'y' + yoon[n]
            i += 2
        elif c == 'ッ': dbl = True; i += 1; continue
        elif c == 'ー':
            if out:
                last = out[-1]
                v = next((ch for ch in reversed(last) if ch in 'aeiou'), '')
                out[-1] = last + v
            i += 1; continue
        elif c in base:
            syl = base[c]; i += 1
            if c == 'ン' and i < len(s) and (s[i] in 'アイウエオヤユヨ'): syl = "n'"
        else:
            syl = c if c in ' /・、,()' else ''; i += 1
            if c == '・': syl = ' '
        if syl is None: continue
        if dbl and syl and syl[0] not in "aeiou'":
            syl = ('t' if syl.startswith('ch') else syl[0]) + syl
        dbl = False
        out.append(syl)
    r = ''.join(out)
    return re.sub(r'\s+', ' ', r).strip()

# ---------------- kanji poc habituals (es mostren entre parèntesis) ----------------
RARE = set('''何時も 偶に 滅多に 屡々 又 一々 直ぐ 未だ 軈て 何時か 何時でも 疾っくに つい先 予め 取り敢えず 暫く 漸く 到頭 先ず 咄嗟に 何れ
迚も 一寸 可也 稍 酷く 只 悉く 丸で 恰も 略 取り分け 殊に 益々 却って 寧ろ 然程 其れ程 碌に 矢鱈に 無闇に 凡そ 大凡 疎らに
態と 態々 屹度 矢張り 矢っ張り 偶々 強ち 生憎 如何にも 如何 兎に角 兎も角 彼方此方 其処ら中 此方 其方 彼方 何方 延いては 兎角
愈々 何時までも 序でに 成る可く 未だ未だ 些か 最早 先ず先ず 若し 詰まり 然も 因みに 様に 内に 為に にも拘らず 即ち 就いては 尤も 何れにしても 癖に
有る 居る 為る 屈む 躓く 遣る 呉れる 擽る 抓る 揶揄う 苛める 躾ける 嚔をする 齧る 巫山戯る 燥ぐ 凭れる 熟す 齎す 躊躇う 彷徨う 攀じ登る 擦り潰す 捏ねる 装う 濯ぐ 苛々する
煩い 喧しい 狡い 擽ったい 怠い 塩っぱい 余所余所しい 吝嗇
御神籤 饂飩 御数 お八つ 大蒜 萌やし 玉蜀黍 桜桃 無花果 家鴨 栗鼠 縞馬 海豚 海豹 水母 鸚鵡 蜻蛉 驢馬 洗熊 樹懶 壁蝨 御玉杓子 井守 針鼠 土竜 犀 苛め 如雨露 迚'''.split())

def kj(kana, kanji):
    if kanji in ('—', '', kana): return '—'
    return f'({kanji})' if kanji in RARE else kanji

# ---------------- lectura de dades ----------------
def read(prefix, nf):
    secs = collections.OrderedDict(); cur = None
    for f in sorted(glob.glob(f'data/{prefix}[0-9]*.txt')):
        for l in open(f, encoding='utf-8'):
            l = l.rstrip('\n')
            if not l.strip(): continue
            if l.startswith('#'):
                cur = l[1:].strip(); secs.setdefault(cur, []); continue
            p = l.split('|')
            if len(p) != nf: continue
            secs[cur].append(p)
    return secs

N = read('n', 5); V = read('v', 7); A = read('a', 6); D = read('d', 5); C = read('c', 6); KANA = read('k', 11)

# reordenar seccions de noms: pronoms/interrogatius/gramaticals/comptadors després de Nombres
order = list(N.keys()); move = ['Pronoms i demostratius','Interrogatius','Paraules gramaticals i generals','Comptadors']
for m in move: order.remove(m)
idx = order.index('Nombres') + 1
order = order[:idx] + move + order[idx:]
N = collections.OrderedDict((k, N[k]) for k in order)

def key(p): return (p[0], p[1] if p[1] not in ('—', p[0]) else '')
other = set()
for S in (V, A, D, C):
    for rows in S.values():
        for p in rows: other.add(key(p))
suru = {}
for rows in V.values():
    for p in rows:
        if p[0].endswith('する'): suru[(p[0][:-2], (p[1][:-2] if p[1] not in ('—',) and p[1].endswith('する') else ''))] = p
removed = {}
seen = set()
for sec in N:
    keep = []
    for p in N[sec]:
        k = key(p)
        if k in other or k in seen: continue
        if (p[0], k[1]) in suru:
            removed[(p[0], k[1])] = p[2]; continue
        seen.add(k); keep.append(p)
    N[sec] = keep
# afegir el significat del nom als verbs amb する
for rows in V.values():
    for p in rows:
        if p[0].endswith('する'):
            kk = (p[0][:-2], p[1][:-2] if p[1].endswith('する') else '')
            if kk in removed:
                noun = p[1][:-2] if p[1].endswith('する') else p[0][:-2]
                p[4] = f"{p[4]}  [nom {noun}: {removed[kk]}]"

cnt = lambda S: sum(len(v) for v in S.values())
COUNTS = dict(n=cnt(N), v=cnt(V), a=cnt(A), d=cnt(D), c=cnt(C), k=cnt(KANA))
print(COUNTS, 'noms absorbits per verbs する:', len(removed))

# ---------------- estils ----------------
DARK = '1F3864'; BLUE = '2E75B6'
thin = Side(style='thin', color='BFBFBF'); BOX = Border(left=thin, right=thin, top=thin, bottom=thin)
F_HEAD = Font(name='Calibri', bold=True, size=10, color='FFFFFF')
F_SEC = Font(name='Calibri', bold=True, size=11, color='FFFFFF')
F_BODY = Font(name='Calibri', size=10)
F_JP = Font(name='Yu Gothic', size=12, bold=True, color=DARK)
F_JPS = Font(name='Yu Gothic', size=10)
FILL_H = PatternFill('solid', fgColor=DARK); FILL_S = PatternFill('solid', fgColor=BLUE)
WRAP = Alignment(wrap_text=True, vertical='center'); WRAPC = Alignment(wrap_text=True, vertical='center', horizontal='center')

def vis_len(s):
    return sum(2 if ord(ch) > 0x2E80 else 1 for ch in str(s))

def set_height(ws, r, values, widths, base=15):
    lines = 1
    for v, w in zip(values, widths):
        if v is None: continue
        lines = max(lines, math.ceil(vis_len(v) / max(w * 1.05, 1)))
    ws.row_dimensions[r].height = max(base, 14 * lines + 4)

wb = Workbook(); wb.remove(wb.active)

def vocab_sheet(name, headers, widths, secs, rowfn, jpcols, tab=BLUE, center=()):
    ws = wb.create_sheet(name); ws.sheet_properties.tabColor = tab
    for i, w in enumerate(widths, 1): ws.column_dimensions[get_column_letter(i)].width = w
    for i, h in enumerate(headers, 1):
        c = ws.cell(1, i, h); c.font = F_HEAD; c.fill = FILL_H; c.alignment = WRAPC; c.border = BOX
    ws.row_dimensions[1].height = 32
    r = 2
    for sec, rows in secs.items():
        if not rows: continue
        for i in range(1, len(headers)+1):
            c = ws.cell(r, i); c.fill = FILL_S
        c = ws.cell(r, 1, sec); c.font = F_SEC; c.alignment = Alignment(vertical='center')
        ws.row_dimensions[r].height = 20; r += 1
        for p in rows:
            vals = rowfn(p)
            for i, v in enumerate(vals, 1):
                c = ws.cell(r, i, v); c.border = BOX; c.alignment = WRAPC if i in center else WRAP
                c.font = F_JP if i in jpcols else (F_JPS if i in (len(headers)-2,) else F_BODY)
            set_height(ws, r, vals, widths); r += 1
    last = r - 1
    dv = DataValidation(type='list', formula1='"✓"', allow_blank=True)
    ws.add_data_validation(dv); dv.add(f'{get_column_letter(len(headers))}2:{get_column_letter(len(headers))}{last}')
    ws.freeze_panes = 'C2'
    ws.auto_filter.ref = f'A1:{get_column_letter(len(headers))}{last}'
    return ws

# ---------------- Guia (s'omple al final) ----------------
guia = wb.create_sheet('Guia'); guia.sheet_properties.tabColor = 'C00000'

# ---------------- Kana ----------------
ws = wb.create_sheet('Kana'); ws.sheet_properties.tabColor = '7030A0'
hk = ['Hiragana','Katakana','Romaji','Fila / combinació','So (fonètica CA)','Nota','Paraula exemple','Kanji','Romaji paraula','Català','Frase (JP)','Frase (CA)','Après (✓)']
wk = [10,10,9,12,16,44,16,10,16,20,30,30,9]
for i, w in enumerate(wk, 1): ws.column_dimensions[get_column_letter(i)].width = w
for i, h in enumerate(hk, 1):
    c = ws.cell(1, i, h); c.font = F_HEAD; c.fill = FILL_H; c.alignment = WRAPC; c.border = BOX
ws.row_dimensions[1].height = 32; r = 2
for sec, rows in KANA.items():
    for i in range(1, len(hk)+1): ws.cell(r, i).fill = FILL_S
    c = ws.cell(r, 1, sec); c.font = F_SEC; ws.row_dimensions[r].height = 20; r += 1
    for p in rows:
        hi, ka, ro, fila, so, nota, wk_, kjj, cat, fr, frc = p
        vals = [hi, ka, ro, fila, so, nota, wk_, kj(wk_, kjj), romaji(wk_), cat, fr, frc, None]
        for i, v in enumerate(vals, 1):
            c = ws.cell(r, i, v); c.border = BOX
            c.alignment = WRAPC if i <= 4 else WRAP
            c.font = Font(name='Yu Gothic', size=16, bold=True, color=DARK) if i in (1, 2) else (F_JP if i in (7, 8) else F_BODY)
        set_height(ws, r, vals, wk, base=24); r += 1
dv = DataValidation(type='list', formula1='"✓"', allow_blank=True); ws.add_data_validation(dv); dv.add(f'M2:M{r-1}')
ws.freeze_panes = 'C2'

# ---------------- Vocabulari ----------------
vocab_sheet('Noms', ['Català','Kana','Kanji','Romaji','Frase (JP)','Frase (CA)','Après (✓)'], [30,18,14,20,40,42,9], N,
            lambda p: [p[2], p[0], kj(p[0], p[1]), romaji(p[0]), p[3], p[4], None], jpcols=(2,3))
GR = {'I':'1 · godan','II':'2 · ichidan','III':'3 · irregular'}
TR = {'t':'transitiu','i':'intransitiu','t/i':'tr. / intr.','i/t':'tr. / intr.'}
vocab_sheet('Verbs', ['Català','Kana','Kanji','Romaji','Grup','Tr. / Intr.','Frase (JP)','Frase (CA)','Après (✓)'], [32,20,14,20,13,12,40,42,9], V,
            lambda p: [p[4], p[0], kj(p[0], p[1]), romaji(p[0]), GR.get(p[2], p[2]), TR.get(p[3], p[3]), p[5], p[6], None], jpcols=(2,3), center=(5,6))
vocab_sheet('Adjectius', ['Català','Kana','Kanji','Romaji','Tipus','Frase (JP)','Frase (CA)','Après (✓)'], [30,20,14,20,9,40,42,9], A,
            lambda p: [p[3], p[0], kj(p[0], p[1]), romaji(p[0]), p[2], p[4], p[5], None], jpcols=(2,3), center=(5,))
vocab_sheet('Adverbis', ['Català','Kana','Kanji','Romaji','Frase (JP)','Frase (CA)','Après (✓)'], [32,18,14,20,40,42,9], D,
            lambda p: [p[2], p[0], kj(p[0], p[1]), romaji(p[0]), p[3], p[4], None], jpcols=(2,3))
vocab_sheet('Connectors', ['Català','Connector','Kanji','Romaji','Tipus','Frase (JP)','Frase (CA)','Après (✓)'], [30,16,12,18,24,42,44,9], C,
            lambda p: [p[2], p[0], kj(p[0], p[1]), romaji(p[0]), p[3], p[4], p[5], None], jpcols=(2,3), tab='BF8F00')

# ---------------- Fulls de gramàtica ----------------
def gram_sheet(name, blocks, ncol=8, width=25, widths=None):
    ws = wb.create_sheet(name); ws.sheet_properties.tabColor = '548235'; ws.sheet_view.showGridLines = False
    widths = widths or [width]*ncol
    for i, w in enumerate(widths, 1): ws.column_dimensions[get_column_letter(i)].width = w
    total = sum(widths); r = 1
    for b in blocks:
        kind = b[0]
        if kind == 'T':
            ws.merge_cells(start_row=r, start_column=1, end_row=r, end_column=ncol)
            c = ws.cell(r, 1, b[1]); c.font = Font(bold=True, size=12, color='FFFFFF'); c.fill = FILL_S; c.alignment = WRAP
            ws.row_dimensions[r].height = 24
        elif kind == 'P':
            ws.merge_cells(start_row=r, start_column=1, end_row=r, end_column=ncol)
            c = ws.cell(r, 1, b[1]); c.font = F_BODY; c.alignment = Alignment(wrap_text=True, vertical='top')
            ws.row_dimensions[r].height = max(18, 14 * math.ceil(vis_len(b[1]) / (total * 1.1)) + 6)
        elif kind == 'H':
            for i, v in enumerate(b[1], 1):
                c = ws.cell(r, i, v); c.font = F_HEAD; c.fill = FILL_H; c.alignment = WRAPC; c.border = BOX
            set_height(ws, r, b[1], widths, base=22)
        elif kind == 'R':
            for i, v in enumerate(b[1], 1):
                c = ws.cell(r, i, v); c.border = BOX; c.alignment = WRAP
                jp = any(ord(ch) > 0x3000 for ch in str(v))
                c.font = Font(name='Yu Gothic' if jp else 'Calibri', bold=(i == 1), size=11 if jp else 10)
            set_height(ws, r, b[1], widths, base=18)
        r += 1
    return ws

gram_sheet('Conjugació', gram_verbs.B, ncol=8, widths=[24,24,22,22,22,22,22,22])
gram_sheet('Partícules', gram_particles.B, ncol=5, widths=[20,26,48,34,36])
gram_sheet('Adjectius i adverbis', gram_adj.B, ncol=5, widths=[26,32,30,34,34])
gram_sheet('Preposicions', gram_post.B, ncol=6, widths=[26,26,30,30,30,24])
gram_sheet('Oracions', gram_sent.B, ncol=5, widths=[8,26,56,38,40])

# ---------------- Guia ----------------
g = guia
for col, w in zip('ABC', (32, 74, 50)): g.column_dimensions[col].width = w
g.sheet_view.showGridLines = False
rows = []
def gt(t): rows.append(('title', t))
def gh(t): rows.append(('head', t))
def gk(a, b, c=None): rows.append(('kv', a, b, c))
def gb(): rows.append(('blank',))
gt("Japonès A1–B2: quadern d'estudi")
gb(); gh('Contingut')
gk('Recompte', f"Kana: {COUNTS['k']} files  ·  Noms: {COUNTS['n']}  ·  Verbs: {COUNTS['v']}  ·  Adjectius: {COUNTS['a']}  ·  Adverbis: {COUNTS['d']}  ·  Connectors: {COUNTS['c']}")
gk('Com està organitzat', "Cada fila de vocabulari: traducció al català a la primera columna, la paraula en kana (hiragana o katakana), el kanji, el romaji, una frase en japonès i la seva traducció. Els temes són files de separació blaves (no columnes). Els oposats (obrir/tancar, entrar/sortir, gran/petit, sempre/mai…) van seguits. Fes servir el filtre només dins de cada bloc. La columna «Après» és un desplegable amb ✓ per marcar el que ja saps.")
gk('Sense repeticions', "Cap paraula (mateixa lectura i mateix kanji) surt dues vegades al fitxer. Hi ha paraules diferents que s'escriuen igual però es llegeixen diferent (一日: いちにち «un dia» / ついたち «dia u»), i homòfons amb kanji diferent (はし: 橋 pont / 箸 bastonets); són paraules diferents.")
gk('Verbs amb する', f"Molts verbs són un nom + する (勉強する = estudiar, de 勉強 «estudi»). Per no repetir, aquests {len(removed)} noms NO surten a Noms: el seu significat com a nom apareix entre claudàtors a la traducció del verb, p. ex. «estudiar  [nom 勉強: estudi]».")
gk('Kanji entre parèntesis', "Si el kanji surt entre parèntesis, p. ex. (迚も), existeix però a la pràctica la paraula s'escriu gairebé sempre en kana. Si surt «—», la paraula no té kanji (katakana o kana).")
gb(); gh('Pestanyes')
for a, b in [('Kana', "Hiragana i katakana: les 46 bàsiques, sonores (゛゜), combinades (きゃ…), signes especials (っ, ー) i combinacions per a paraules estrangeres. Amb so per a catalanoparlants, nota, paraula i frase d'exemple."),
             ('Noms', 'Per temes, seguint els grups dels teus PDF. La part d’informàtica en katakana s’ha tret; es conserven els termes tecnològics amb kanji i s’hi han afegit pronoms, interrogatius, comptadors i paraules gramaticals.'),
             ('Verbs', "Per tema i ús, amb grup (1 godan, 2 ichidan, 3 irregular) i transitiu / intransitiu. Les parelles transitiu-intransitiu i els oposats van seguits."),
             ('Adjectius', "Per tema; tipus い o な; oposats seguits."),
             ('Adverbis', "Per tema (freqüència, temps, grau, quantitat, manera, probabilitat, actitud, mimètics…); oposats seguits."),
             ('Connectors', "Connectors i conjuncions agrupats per nivell A1, A2, B1 i B2. «〜» indica que s'enganxen a un verb o frase."),
             ('Conjugació', "Els tres grups de verbs, les cinc bases del godan (segons el gràfic que vas adjuntar), taula completa de formes, present / passat / futur, usos de cada forma, transitius-intransitius, donar-rebre i honorífics."),
             ('Partícules', "Partícules de cas, d'èmfasi i de final de frase; は vs が; に / で / を amb llocs."),
             ('Adjectius i adverbis', "Conjugació dels adjectius い i な, l'irregular いい, sufixos, comparació, formació d'adverbis i adverbis que demanen negació o una forma concreta."),
             ('Preposicions', "El japonès té posposicions: taula on / cap a on / d'on, noms de posició, temps, posposicions compostes i règim verbal."),
             ('Oracions', "Estructura de l'oració de A1 a B2 i totes les subordinades: relatives, temporals, condicionals, concessives, finals, causals, interrogatives indirectes, estil indirecte, registres i puntuació.")]:
    gk(a, b)
gb(); gh('Clau del romaji (per a catalanoparlants)')
for a, b, c in [('Sistema', "Romaji generat automàticament a partir del kana, lletra per lletra: les vocals llargues es dupliquen (コーヒー = koohii, がっこう = gakkou, せんせい = sensei).", "Així el romaji coincideix sempre amb el kana; en molts llibres trobaràs ō / ū en lloc de ou / uu."),
                ('Vocals', "a, i, u, e, o com en català; la u, sense arrodonir els llavis.", "La i i la u sovint gairebé no sonen entre consonants sordes: です ≈ «des», ました ≈ «maxta»."),
                ('sh / ch / j', "sh = «x» de «xiular»; ch = «tx» de «cotxe»; j = «dj» (com «jo» però amb d).", None),
                ('ts / z', "ts = «ts» de «potser»; z = «z» de «zero».", None),
                ('r', "Una sola vibració, entre la «r» de «cara» i la «l». Mai «rr».", None),
                ('h / f', "h aspirada (com en anglès); f = bufar amb els llavis, entre f i h.", None),
                ('s', "Sempre sorda: «ss» (mai com la s de «casa»).", None),
                ('g', "Sempre «g» de «gat»: ge = «gue», gi = «gui».", None),
                ('Doble consonant', "kk, tt, ss, pp = una petita pausa abans de la consonant (っ).", "きって (kitte) ≠ きて (kite)."),
                ("n'", "La ん davant de vocal o y s'escriu n' per evitar confusió.", "きんえん = kin'en."),
                ('Partícules', "は, へ, を com a partícula es pronuncien wa, e, o.", None)]:
    gk(a, b, c)
gb(); gh("Llegeix això abans de fiar-te del fitxer")
for a, b in [('Selecció de paraules', "Les paraules surten dels teus PDF (seleccionades, ordenades i sense repetir) i les he completades jo per arribar als recomptes. No és una llista de freqüència verificada. Si vols rigor estadístic, contrasta-la amb «A Frequency Dictionary of Japanese» (Yukio Tono, Makoto Yamazaki i Kikuo Maekawa, Routledge)."),
             ('Recomptes', f"Noms ≈ 3000, verbs ≈ 1500 i adjectius ≈ 800 s'han assolit. Adverbis: n'hi ha {COUNTS['d']}, no 1000. El japonès no té 1000 adverbis d'ús comú: arribar-hi voldria dir farcir la llista amb formes derivades d'adjectius (優しく, 静かに…, que ja surten a Adjectius) o amb onomatopeies molt rares. He preferit no repetir ni inventar."),
             ('Traduccions i frases', "Traduccions al català i frases d'exemple escrites per mi. No estan revisades per un parlant nadiu ni contrastades amb un diccionari una per una: si una frase et sembla estranya, comprova-la (Jisho.org, Weblio o un professor). Algunes traduccions són aproximades perquè la paraula té diversos sentits."),
             ('Frases sense lectura', "Les frases d'exemple porten kanji i no tenen furigana: en aquest entorn no tenia accés a cap diccionari morfològic per generar la lectura automàticament i no l'he volgut escriure a mà per a 6000 frases sense poder-la verificar. La lectura de cada paraula sí que hi és (columnes Kana i Romaji)."),
             ('Romaji', "Generat per programa a partir del kana que he escrit jo. És fidel al kana, però no marca l'accent tonal del japonès."),
             ('Nivells A1–B2', "L'assignació de nivells als connectors i a les estructures és estimació meva, no d'una font oficial (el JLPT no publica llistes oficials de vocabulari)."),
             ('Dades que poden haver canviat', "Res d'aquest fitxer depèn de dades en temps real.")]:
    gk(a, b)

r = 1
for row in rows:
    if row[0] == 'title':
        c = g.cell(r, 1, row[1]); c.font = Font(bold=True, size=16, color=DARK); g.row_dimensions[r].height = 26
    elif row[0] == 'head':
        for col in range(1, 4): g.cell(r, col).fill = FILL_S
        c = g.cell(r, 1, row[1]); c.font = Font(bold=True, size=12, color='FFFFFF'); g.row_dimensions[r].height = 20
    elif row[0] == 'kv':
        a = g.cell(r, 1, row[1]); a.font = Font(bold=True, size=10); a.alignment = Alignment(wrap_text=True, vertical='top')
        b = g.cell(r, 2, row[2]); b.font = Font(size=10); b.alignment = Alignment(wrap_text=True, vertical='top')
        if row[3]:
            c = g.cell(r, 3, row[3]); c.font = Font(size=10, italic=True); c.alignment = Alignment(wrap_text=True, vertical='top')
        set_height(g, r, [row[1], row[2], row[3]], [32, 74, 50], base=16)
    r += 1

wb.move_sheet('Guia', offset=-wb.index(wb['Guia']))
wb.active = 0
wb.save(OUT)
print('saved', OUT)
