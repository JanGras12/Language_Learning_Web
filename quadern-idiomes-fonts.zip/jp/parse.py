import re,sys,json
S='/tmp/claude-0/-home-claude/72a36073-385f-5e57-9bd4-5b241f591610/scratchpad/pdf/'
JP=re.compile(r'[぀-ヿ一-鿿]')
def parse(fn):
    out=[];chap='';sec=''
    lines=open(S+fn).read().split('\n')
    for ln in lines:
        s=ln.strip()
        if not s or '.....' in s: continue
        parts=re.split(r'\s{2,}',s)
        if s.startswith('Chapter'): chap=s; sec=''; continue
        if len(parts)>=3 and JP.search(parts[0]) and JP.search(parts[1]):
            out.append(dict(ch=chap,sec=sec,jp=parts[0],rd=parts[1],en=' '.join(parts[2:])))
        elif len(parts)==1 and re.search(r'[A-Za-z]',s) and len(s)<70 and not s.startswith('Japanese'):
            sec=s
    return out
res={}
for k,f in [('n','b0e66246-Japanese.txt'),('v','0c7c2c27-Japanese-1.txt'),('a','a9f2153c-Japanese-2.txt'),('d','10997a03-Japanese-3.txt')]:
    e=parse(f); res[k]=e
    uniq={(x['jp'],x['rd']) for x in e}
    print(k,len(e),len(uniq))
json.dump(res,open('src.json','w'),ensure_ascii=False,indent=0)
